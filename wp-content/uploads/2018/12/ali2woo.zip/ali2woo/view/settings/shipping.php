
    <form method="post" enctype='multipart/form-data'>
        <input type="hidden" name="setting_form" value="1"/>
         <div class="panel panel-primary mt20">
                <div class="panel-heading">
                    <h3 class="display-inline"><?php _ex('Shipping settings', 'Setting title', 'a2w'); ?></h3>
                </div>
                
                <div class="panel-body">
                        <div class="row">
                            <div class="col-md-4">
                                <label>
                                    <strong><?php _ex('Use Aliexpress Shipping', 'Setting title', 'a2w'); ?></strong>
                                </label>
                                <div class="info-box" data-toggle="tooltip" title="<?php _ex('Show the shipping drop-down selection in Frontend (Cart, Checkout and Order page)', 'setting description', 'a2w'); ?>"></div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group input-block no-margin">
                                      <input type="checkbox" class="form-control small-input" id="a2w_aliship_frontend" name="a2w_aliship_frontend" <?php if (get_option('a2w_aliship_frontend')): ?>value="yes" checked<?php endif; ?> />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label>
                                    <strong><?php _ex('Default Shipping Country', 'Setting title', 'a2w'); ?></strong>
                                </label>
                                <div class="info-box" data-toggle="tooltip" title="<?php _ex('Set the Default option for Country drop-down selection in Frontend (Cart and Checkout pages)', 'setting description', 'a2w'); ?>"></div>
                            </div>
                            <div class="col-md-8">
                                <?php  $cur_a2w_aliship_shipto = get_option('a2w_aliship_shipto', 'US'); ?>
                                <div class="form-group input-block no-margin">
                                    <select name="a2w_aliship_shipto" id="a2w_aliship_shipto" <?php if (!get_option('a2w_aliship_frontend', false)): ?>disabled<?php endif; ?>>
                                      <?php foreach ($shipping_countries as  $country): ?>
                                        <option value="<?php echo $country['c']; ?>"<?php if ($cur_a2w_aliship_shipto == $country['c']): ?> selected<?php endif; ?>>
                                            <?php echo $country['n']; ?>
                                        </option>
                                      <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                   
                     
                </div> 
         </div>
         
       
            <div class="row pt20 border-top">
                <div class="col-sm-12">
                       <input class="btn btn-success" type="submit" value="<?php _e('Save settings', 'a2w'); ?>"/>
                </div>
            </div>
     
    </form>

<script>
     function a2w_isInt(value) {
          return !isNaN(value) && 
                 parseInt(Number(value)) == value && 
                 !isNaN(parseInt(value, 10));
     }
        
    (function ($) {
         
        $('[data-toggle="tooltip"]').tooltip({ "placement": "top"});
        
        $('.a2w-content form').on('submit', function(){
            if ($(this).find('.has-error').length > 0 ) return false;    
        });   
        
        $("#a2w_aliship_frontend").change(function () {
            $("#a2w_aliship_shipto").prop('disabled', !$(this).is(':checked'));
            return true;
        }); 
            
    })(jQuery);
    

  

</script>