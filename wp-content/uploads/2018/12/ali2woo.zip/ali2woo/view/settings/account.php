
    <form method="post">
        <input type="hidden" name="setting_form" value="1"/>
        <div class="account_options<?php if ($account->custom_account): ?> custom_account<?php endif; ?>">
            <div class="panel panel-primary mt20">
                    <div class="panel-heading">
                        <h3 class="display-inline"><?php _ex('Account settings', 'Setting title', 'a2w'); ?></h3>
                    </div>
                      <div class="panel-body">
                            <div class="row">
                                <div class="col-xs-12 col-sm-4">
                                    <label>
                                        <strong><?php _ex('Use custom account', 'a2w'); ?></strong>
                                    </label>
                                    <div class="info-box" data-toggle="tooltip" title="<?php _ex('You can use your own Aliexpress API Keys if needed', 'setting description', 'a2w'); ?>"></div>
                                </div>
                                <div class="col-xs-12 col-sm-8">
                                        <div class="form-group input-block no-margin clearfix">
                                            <input type="checkbox" class="form-control float-left mr20" id="a2w_use_custom_account" name="a2w_use_custom_account" value="yes" <?php if ($account->custom_account): ?>checked<?php endif; ?>/>
                                            <div class="default_account">
                                                <?php _ex('You are using default account', 'a2w'); ?>
                                             </div>
                                        </div>                                                                     
                                </div>
                            </div>
                
                                <div class="row account_fields">
                                    <div class="col-sm-4">
                                        <label>
                                            <strong><?php _ex('APP Key', 'a2w'); ?></strong>
                                        </label>
                                        <div class="info-box" data-toggle="tooltip" title="<?php _ex('When you create the App, the AliExpress open platform will generate an appKey', 'setting description', 'a2w'); ?>"></div>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="form-group input-block no-margin">
                                             <input type="text" class="form-control small-input" id="a2w_appkey" name="a2w_appkey" value="<?php echo $account->custom_appkey ?>"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="row account_fields">
                                    <div class="col-sm-4">
                                        <label>
                                            <strong><?php _ex('TrackingId', 'a2w'); ?></strong>
                                        </label>
                                        <div class="info-box" data-toggle="tooltip" title="<?php _ex('The tracking ID of your account in the Portals platform', 'setting description', 'a2w'); ?>"></div>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="form-group input-block no-margin">
                                             <input type="text" class="form-control small-input" id="a2w_trackingid" name="a2w_trackingid" value="<?php echo $account->custom_trackingid ?>"/>
                                        </div>
                                    </div>
                                </div>
                    </div>       
            </div>  
        </div>
            <div class="row pt20 border-top">
                <div class="col-sm-12">
                      <input class="btn btn-success js-main-submit" type="submit" value="<?php _e('Save settings', 'a2w'); ?>"/>
                </div>
            </div>
   
    </form>

    <script>
        (function ($) {
            $('[data-toggle="tooltip"]').tooltip({ "placement": "top"});
            
            $("#a2w_use_custom_account").change(function () {
                if($(this).is(':checked')){
                    $(this).parents('.account_options').addClass('custom_account');
                }else{
                    $(this).parents('.account_options').removeClass('custom_account');
                }
                return true;
            });
        })(jQuery);
    </script>