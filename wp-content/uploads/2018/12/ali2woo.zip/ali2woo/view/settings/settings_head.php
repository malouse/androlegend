<h1>Aliexpress Dropship Settings</h1>
<div class="a2w-content">
    <?php include_once A2W()->plugin_path . 'view/chrome_notify.php'; ?>
    <ul class="nav nav-tabs">
      <?php foreach($modules as $module):?>
      <li role="presentation" <?php echo $current_module == $module['id'] ? 'class="active"' : ""; ?>><a href="<?php echo admin_url('admin.php?page=a2w_setting&subpage='.$module['id']); ?>"><?php echo $module['name'] ?></a></li>
      <?php endforeach; ?>
    </ul>
    <?php /*
    <h2 class="nav-tab-wrapper">
        <?php foreach($modules as $module):?>
            <a href="<?php echo admin_url('admin.php?page=a2w_setting&subpage='.$module['id']); ?>" class="nav-tab<?php echo $current_module == $module['id'] ? " nav-tab-active" : ""; ?>"><?php echo $module['name'] ?></a>
        <?php endforeach; ?>
    </h2>
       */ ?>
