<?php
$a2w_shipping_html = '<div id="a2w_to_country">' .
	woocommerce_form_field('a2w_to_country_field', array(
		   'type'       => 'select',
		   'class'      => array( 'chzn-drop' ),
		   'label'      => __('Ship my order(s) to: ','a2w'),
		   'placeholder'    => __('Select a Country','a2w'),
		   'options'    => $countries,
		   'default' => $default_country,
		   'return' => true
			)
	 ) .
'</div>';
$a2w_shipping_html = str_replace(array("\r", "\n"), '', $a2w_shipping_html);
?>
<div class="a2w_shipping">
</div>
<script>
jQuery(document).ready(function($){
   var v = '<?php echo addslashes($a2w_shipping_html); ?>';

   window.a2w_shipping_api.init_in_cart(v); 
});
</script>
