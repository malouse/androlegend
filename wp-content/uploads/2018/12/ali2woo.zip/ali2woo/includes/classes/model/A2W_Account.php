<?php

/**
 * Description of A2W_Account
 *
 * @author Andrey
 */
if (!class_exists('A2W_Account')) {

    class A2W_Account {
        private static $_instance = null;
        
        public $custom_account = false;
        public $appkey = '';
        public $trackingid = '';
        public $custom_appkey = '';
        public $custom_trackingid = '';
        
        static public function getInstance() {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        protected function __construct() {
            $this->custom_account = get_option('a2w_use_custom_account', false);

            $accounts = get_option('a2w_accounts', array());
            if (is_array($accounts) && $accounts) {
                if (isset($accounts[0]['appkey'])) {
                    $this->custom_appkey = $accounts[0]['appkey'];
                }
                if (isset($accounts[0]['trackingid'])) {
                    $this->custom_trackingid = $accounts[0]['trackingid'];
                }
            }

            if ($this->custom_account) {
                $this->appkey = $this->custom_appkey;
                $this->trackingid = $this->custom_trackingid;
            } else {
                list($this->appkey, $this->trackingid) = explode(';', base64_decode("MTM2NTc7ZGV2Y2FyYm9udXM="));
            }
        }

        public function use_custom_account($use_custom_account = false) {
            $this->custom_account = $use_custom_account;
            update_option('a2w_use_custom_account', $this->custom_account);
        }

        public function save_account($appkey, $trackingid) {
            $this->appkey = $this->custom_appkey = $appkey;
            $this->trackingid = $this->custom_trackingid = $trackingid;
            update_option("a2w_accounts", array(array('appkey' => $this->custom_appkey, 'trackingid' => $this->custom_trackingid)));
        }
        
        public function build_params(){
            if (defined('A2W_ITEM_PURCHASE_CODE') && A2W_ITEM_PURCHASE_CODE) {
                $item_purchase_code = A2W_ITEM_PURCHASE_CODE;
            }else{
                $item_purchase_code = get_option('a2w_item_purchase_code', '');    
            }
            $result="token=".urlencode($item_purchase_code)."&version=".A2W()->version;
            if($this->custom_account){
                $result.="&appkey=".$this->appkey."&trackingid=".$this->trackingid;
            }
            return $result;
        }
    }

}