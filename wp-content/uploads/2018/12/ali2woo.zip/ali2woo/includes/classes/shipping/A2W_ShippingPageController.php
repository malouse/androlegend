<?php
/**
 * Description of A2W_ShippingPageController
 *
 * @author MA_GROUP
 * 
 * @autoload: true
 */
if (!class_exists('A2W_ShippingPageController')):

    class A2W_ShippingPageController extends A2W_AbstractAdminPage {

        public function __construct() {
            parent::__construct("Shipping List", "Shipping List", 'manage_options', 'edit.php?post_type=a2w_shipping', 30, true);

            add_filter('a2w_get_order_content', array($this, 'get_order_content'), 10, 2);


            add_action('admin_init', array($this, 'admin_init'));

            add_action('manage_a2w_shipping_posts_columns', array($this, 'get_columns'));
            add_action('manage_a2w_shipping_posts_custom_column', array($this, "edit_columns"));
            add_action('save_post', array($this, 'save_details'));
        }

        public function get_order_content($content, $order_id) {

            $order = new WC_Order($order_id);

            $items = $order->get_items();

            $k = 0;

            foreach ($items as $item) {


                if (isset($item['item_meta']['Shipping'])) {

                    if (is_array($item['item_meta']['Shipping']))
                        $shipping_title = $item['item_meta']['Shipping'][0];
                    else
                        $shipping_title = $item['item_meta']['Shipping'];

                    // if (isset($content[$k])) $content[$k] = str_replace('</span>', ' | ' . $shipping_title . '</span>', $content[$k]);


                    $content[$k] .= '<span class="seller_url_block"> | ' . $shipping_title . '</span>';
                }
                $k++;
            }

            return $content;
        }

        public function render($params = array()) {
            
        }

        public function get_columns($columns) {
            $columns = array(
                "cb" => '<input type="checkbox">',
                "title" => 'Shipping name',
                "initial_name" => "Initial name",
                "service_name" => "Service name",
                "status" => "Status"
            );

            return $columns;
        }

        public function edit_columns($column) {
            global $post;

            switch ($column) {
                case "initial_name":
                    echo get_post_meta($post->ID, 'a2w_text_initial_name', true);
                    break;
                case "service_name":
                    echo get_post_meta($post->ID, 'a2w_service_name', true);
                    break;
                case "status":
                    echo $post->post_status;
                    break;
            }

            return $column;
        }

        public function admin_init() {
            add_meta_box("a2w_shipping_settings_metabox", "Shipping settings", array($this, "settings_metabox"), "a2w_shipping", "normal", "high");
        }

        public function settings_metabox() {
            global $post;
            $custom = get_post_custom($post->ID);

            $initial_name = $custom["a2w_text_initial_name"][0];
            $service_name = $custom["a2w_service_name"][0];
            ?>
            <table class="form-table">
                <tr><th><label>Initial Name</label></th><td><input type="text" value="<?php echo $initial_name; ?>" readonly><br/><em>readonly</em></td></tr>
                <tr><th><label>Service Name</label></th><td><input type="text" value="<?php echo $service_name; ?>" readonly><br/><em>readonly</em></td></tr>
            </table>
            <?php
        }

        public function save_details() {
            global $post;

            //save some fields..
        }

    }

    

	
endif;