<?php

/**
 * Description of A2W_PhraseFilter
 *
 * @author ma_group
 */
class A2W_PhraseFilter {

    public $id = 0;
    public $phrase = '';
    public $phrase_replace = '';

    public function __construct($data = 0) {
        if (is_int($data) && $data) {
            $this->id = $data;
            $this->load($this->id);
        } else if (is_array($data)) {
            foreach ($data as $field => $value) {
                if (property_exists(get_class($this), $field)) {
                    $this->$field = esc_attr(trim($value));
                }
            }
        }
    }
/*
    public function load($id = false) {
        $load_id = $id ? $id : ($this->id ? $this->id : 0);
        if ($load_id) {
            $formula_list = A2W_PriceFormula::load_formulas_list(false);
            foreach ($formula_list as $formula) {
                if (intval($formula['id']) === intval($load_id)) {
                    foreach ($formula as $field => $value) {
                        if (property_exists(get_class($this), $field)) {
                            $this->$field = esc_attr($value);
                        }
                    }
                    break;
                }
            }
        }
        return $this;
    }*/

    public function save() {
        $formula_list = A2W_PhraseFilter::load_phrase_list(false);

        if (!intval($this->id)) {
            $this->id = 1;
            foreach ($formula_list as $key => $formula) {
                if (intval($formula['id']) >= $this->id) {
                    $this->id = intval($formula['id']) + 1;
                }
            }
            $formula_list[] = get_object_vars($this);
        } else {
            $boolean = false;
            foreach ($formula_list as $key => $formula) {
                if (intval($formula['id']) === intval($this->id)) {
                    $formula_list[$key] = get_object_vars($this);
                    $boolean = true;
                }
            }
            if (!$boolean) {
                $formula_list[] = get_object_vars($this);
            }
        }

        update_option('a2w_phrase_list', array_values($formula_list));

        return $this;
    }

    public function delete() {
        $formula_list = A2W_PhraseFilter::load_phrase_list(false);
        foreach ($formula_list as $key => $formula) {
            if (intval($formula['id']) === intval($this->id)) {
                unset($formula_list[$key]);
                update_option('a2w_phrase_list', array_values($formula_list));
            }
        }
    }
    
    /**
    * Apply phrase filter to wc product (title, description, attributes)
    * 
    * @param mixed $product
    */
    public static function apply_filter_to_product($product){
        
        if ($product['title']) 
            $product['title'] = self::apply_filter_to_text($product['title']);
            
        if ($product['description']) 
            $product['description'] = self::apply_filter_to_text($product['description']);
            
        if (isset($product['attribute']) && is_array($product['attribute'])){
            foreach ($product['attribute'] as &$attr){
                $attr['name'] = self::apply_filter_to_text($attr['name']);  
                $attr['value'] = self::apply_filter_to_text($attr['value']); 
            }
        }
           
        //todo: variations ?
        
        return $product;  
    }
    
    public static function apply_filter_to_products(){
        $phrase = array(); $phrase_replace = array();
        $formula_list = A2W_PhraseFilter::load_phrase_list(false);
        foreach ($formula_list as $key => $formula) {
            $result = self::query_replace_phrase_in_products($formula['phrase'], $formula['phrase_replace']);
        } 
        
        //todo: return count of updated rows? process false in the controller?
        return $result;    
    }
    
    /**
    * Apply phrase filter to any text 
    * 
    * @param mixed $text
    */
    public static function apply_filter_to_text($text){
        $phrase = array(); $phrase_replace = array();
        $formula_list = A2W_PhraseFilter::load_phrase_list(false);
        foreach ($formula_list as $key => $formula) {
            $phrase[] = $formula['phrase'];
            $phrase_replace[] = $formula['phrase_replace'];
        }  
        
        if (!empty($phrase)){
            $text = str_replace($phrase, $phrase_replace, $text);
        }  
        
        return $text;
    }
     
     /**
     * Apply phrase filter to reviews keeping in database currently (review author, review text)
     * 
     */
    public static function apply_filter_to_reviews(){
               
        $phrase = array(); $phrase_replace = array();
        $formula_list = A2W_PhraseFilter::load_phrase_list(false);
        foreach ($formula_list as $key => $formula) {
            $result = self::query_replace_phrase_in_reviews($formula['phrase'], $formula['phrase_replace']);
        } 
        
        //todo: return count of updated rows? process false in the controller?
        return $result;
    
     }
     
     /**
     * Return number of updated rows during the update operation or false if db error has been occured
     * 
     * @param mixed $phrase
     * @param mixed $phrase_replace
     */
    private static function query_replace_phrase_in_reviews($phrase, $phrase_replace){
     
             global $wpdb;
              
             $like_exp = $wpdb->esc_like( $phrase );
             $like_exp = '%' . $like_exp . '%';
             
             
             
             $sql = "UPDATE {$wpdb->comments} as t1 "
                    . " LEFT JOIN {$wpdb->commentmeta} as t2 ON t2.comment_id = t1.comment_ID "
                    . " SET `comment_author` = REPLACE(comment_author, %s, %s), "
                    . " `comment_content` = REPLACE(comment_content, %s, %s) " 
                    . " WHERE (`comment_author` LIKE  %s OR `comment_content` LIKE  %s) AND t2.`meta_key` = %s";
                    
             $result = $wpdb->query( $wpdb->prepare( $sql, $phrase, $phrase_replace, 
                                                     $phrase, $phrase_replace, 
                                                     $like_exp, $like_exp, "a2w_country"  ) );
                                                     
             
             //if error and $wpdb->show_errors is set to true, log errors
             if($wpdb->last_error !== '') $wpdb->print_error();
         
             return $result;
 
     }
     
     /**
     * Return number of updated rows during the update operation or false if db error has been occured
     * 
     * @param mixed $phrase
     * @param mixed $phrase_replace
     */
    private static function query_replace_phrase_in_products($phrase, $phrase_replace){
        global $wpdb;
            
             $like_exp = $wpdb->esc_like( $phrase );
             $like_exp = '%' . $like_exp . '%';
             
             
             
             $sql = "UPDATE {$wpdb->posts} as t1 "
                    . " LEFT JOIN {$wpdb->postmeta} as t2 ON t2.post_id = t1.ID "
                    . " SET `post_title` = REPLACE(post_title, %s, %s), "
                    . " `post_content` = REPLACE(post_content, %s, %s) " 
                    . " WHERE (`post_title` LIKE  %s OR `post_content` LIKE  %s) AND t2.`meta_key` = %s";
                    
             $result = $wpdb->query( $wpdb->prepare( $sql, $phrase, $phrase_replace, 
                                                     $phrase, $phrase_replace, 
                                                     $like_exp, $like_exp, "_a2w_import_type"  ) );
                                                     
             
             //if error and $wpdb->show_errors is set to true, log errors
             if($wpdb->last_error !== '') $wpdb->print_error();
         
             return $result;    
    }

    public static function deleteAll() {
        delete_option('a2w_phrase_list');
    }


    public static function load_phrases() {
        return A2W_PhraseFilter::load_phrase_list(true);
    }

    private static function load_phrase_list($asObject = true) {
        $result = array();

        $formula_list = get_option('a2w_phrase_list');
        $formula_list = $formula_list && is_array($formula_list) ? $formula_list : array();
        if ($asObject) {
            foreach ($formula_list as $formula) {
                $fo = new A2W_PhraseFilter();
                foreach ($formula as $name => $value) {
                    if (property_exists(get_class($fo), $name)) {
                        $fo->$name = $value;
                    }
                }
                $result[] = $fo;
            }
        } else {
            $result = $formula_list;
        }

        return $result;
    }

}
