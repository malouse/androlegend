<?php

/**
 * Description of A2W_Woocommerce
 *
 * @author andrey
 */
if (!class_exists('A2W_Woocommerce')) {

    class A2W_Woocommerce {

        private static $active_plugins;
        private $attachment_model;
        private $helper;

        public function __construct() {
            $this->attachment_model = new A2W_Attachment();
            $this->helper = new A2W_Helper();
        }

        public static function is_woocommerce_installed() {
            if (!self::$active_plugins) {
                self::$active_plugins = (array) get_option('active_plugins', array());
                if (is_multisite()) {
                    self::$active_plugins = array_merge(self::$active_plugins, get_site_option('active_sitewide_plugins', array()));
                }
            }

            return in_array('woocommerce/woocommerce.php', self::$active_plugins) || array_key_exists('woocommerce/woocommerce.php', self::$active_plugins);
        }

        public function add_product($product, $params = array()) {
            if (!A2W_Woocommerce::is_woocommerce_installed()) {
                return A2W_ResultBuilder::buildError("Woocommerce is not installed");
            }

            global $wpdb;

            do_action('a2w_woocommerce_before_add_product', $product, $params);

            $loaded_images = array();

            $product_type = (isset($product['product_type']) && $product['product_type']) ? $product['product_type'] : get_option('a2w_default_product_type', 'simple');
            $product_status = (isset($product['product_status']) && $product['product_status']) ? $product['product_status'] : get_option('a2w_default_product_status', 'publish');

            $tax_input = array('product_type' => $product_type);
            $categories = $this->build_categories($product);
            if ($categories) {
                $tax_input['product_cat'] = $categories;
            }

            $post = array(
                'post_title' => isset($product['title']) && $product['title'] ? $product['title'] : "Product " . $product['id'],
                'post_content' => '',
                'post_status' => $product_status,
                'post_name' => isset($product['title']) && $product['title'] ? $product['title'] : "Product " . $product['id'],
                'post_type' => 'product',
                'comment_status' => 'open',
                'tax_input' => $tax_input,
                'meta_input' => array('_stock_status' => 'instock',
                    '_sku' => $product['id'],
                    '_a2w_external_id' => $product['id'],
                    '_product_url' => $product['affiliate_url'],
                    '_a2w_original_product_url' => $product['url'],
                    '_a2w_seller_url' => (!empty($product['seller_url']) ? $product['seller_url'] : ''),
                    '_a2w_import_type' => 'a2w',
                    '_a2w_last_update' => time(),
                    '_a2w_skip_meta' => array('skip_vars' => $product['skip_vars'], 'skip_images' => $product['skip_images']),
                    '_a2w_disable_var_price_change' => isset($product['disable_var_price_change']) && $product['disable_var_price_change'] ? 1 : 0,
                    '_a2w_disable_var_quantity_change' => isset($product['disable_var_quantity_change']) && $product['disable_var_quantity_change'] ? 1 : 0,
                    '_a2w_orders_count' => (!empty($product['ordersCount']) ? intval($product['ordersCount']) : 0),
                ),
            );

            $is_old_product = false;
            $tmp_product_id = $wpdb->get_var($wpdb->prepare("SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_a2w_external_id' AND meta_value='%s' LIMIT 1", $product['id']));
            if (!$tmp_product_id) {
                $product_id = wp_insert_post($post);
            } else {
                $is_old_product = true;
                $product_id = $tmp_product_id;
            }

            $first_ava_var = false;
            if (isset($product['sku_products']['variations'])) {
                foreach ($product['sku_products']['variations'] as $variation) {
                    if (intval($variation['quantity']) > 0) {
                        $first_ava_var = $variation;
                        break;
                    }
                }
            }


            if (get_option('woocommerce_manage_stock', 'no') === 'yes') {
                $tmp_quantity = $first_ava_var ? intval($first_ava_var['quantity']) : 0;
                update_post_meta($product_id, '_manage_stock', 'yes');
                update_post_meta($product_id, '_stock_status', $tmp_quantity ? 'instock' : 'outofstock');
                update_post_meta($product_id, '_stock', $tmp_quantity);
            } else {
                delete_post_meta($product_id, '_manage_stock');
                delete_post_meta($product_id, '_stock_status');
                delete_post_meta($product_id, '_stock');
            }


            $this->update_price($product_id, $first_ava_var);

            if (isset($product['attribute']) && $product['attribute'] && !get_option('a2w_not_import_attributes', false)) {
                $this->set_attributes($product_id, $product['attribute']);
            }

            if (isset($product['tags']) && $product['tags']) {
                wp_set_object_terms($product_id, array_map('sanitize_text_field', $product['tags']), 'product_tag');
            }

            if (isset($product['sku_products']['variations']) && count($product['sku_products']['variations']) > 1) {
                foreach ($product['sku_products']['variations'] as &$var) {
                    $var['skip'] = in_array($var['id'], $product['skip_vars']);
                    $var['image'] = (!isset($var['image']) || in_array(md5($var['image']), $product['skip_images'])) ? '' : $var['image'];
                }
                $this->add_variation($product_id, $product, $loaded_images);
            }

            $thumb_url = '';
            $tmp_all_images = A2W_Utils::get_all_images_from_product($product);
            if (isset($product['thumb_id'])) {
                foreach ($tmp_all_images as $img_id => $img) {
                    if ($img_id === $product['thumb_id']) {
                        $thumb_url = A2W_Utils::clear_url($img['image']);
                        break;
                    }
                }
                /*
                  disable select disable thumb... not use now. uncomment if need use.
                  if(!$thumb_url){
                  $thumb_url = 'empty';
                  }
                 */
            }

            if (isset($product['images'])) {
                $image_to_load = array();
                foreach ($product['images'] as $image) {
                    if (!in_array(md5($image), $product['skip_images'])) {
                        $image_to_load[] = $image;

                        if (!$thumb_url) {
                            // if not thumb not checked, check first available image
                            $thumb_url = $image;
                        }
                    }
                }

                $this->set_images($product_id, $thumb_url, $image_to_load, true, $loaded_images, $post['post_title']);
            }

            wp_update_post(array('ID' => $product_id, 'post_content' => (isset($product['description']) ? $this->build_description($product_id, $product, $loaded_images) : '')));

            wc_delete_product_transients($product_id);

            a2w_delete_transient('wc_attribute_taxonomies');

            do_action('a2w_add_product', $product_id);

            return apply_filters('a2w_woocommerce_after_add_product', A2W_ResultBuilder::buildOk(array('product_id' => $product_id)), $product_id, $product, $params);
        }

        public function upd_product($product_id, $product, $params = array()) {
            do_action('a2w_woocommerce_before_upd_product', $product, $params);

            // first, update some meta
            if (!empty($product['affiliate_url'])) {
                update_post_meta($product_id, '_product_url', $product['affiliate_url']);
            }
            if (!empty($product['url'])) {
                update_post_meta($product_id, '_a2w_original_product_url', $product['url']);
            }
            update_post_meta($product_id, '_a2w_orders_count', (!empty($product['ordersCount']) ? intval($product['ordersCount']) : 0));

            $result = array("state" => "ok", "message" => "");
            $first_ava_var = false;
            if (isset($product['sku_products']['variations'])) {
                foreach ($product['sku_products']['variations'] as $variation) {
                    if (intval($variation['quantity']) > 0) {
                        $first_ava_var = $variation;
                        break;
                    }
                }
            }

            $not_available_product_status = get_option('a2w_not_available_product_status', 'trash');

//$product['disable_var_quantity_change']
//A2W_PREVENT_PRODUCT_QUANTITY_AUTO_UPDATE

            if (get_option('woocommerce_manage_stock', 'no') === 'yes') {
                if ($first_ava_var || $not_available_product_status === 'outofstock') {
                    $tmp_quantity = $first_ava_var ? intval($first_ava_var['quantity']) : 0;
                    update_post_meta($product_id, '_manage_stock', 'yes');
                    update_post_meta($product_id, '_stock_status', $tmp_quantity ? 'instock' : 'outofstock');

                    if (!$product['disable_var_quantity_change']) {
                        update_post_meta($product_id, '_stock', $tmp_quantity);
                    }
                }
            } else {
                delete_post_meta($product_id, '_manage_stock');
                delete_post_meta($product_id, '_stock_status');
                delete_post_meta($product_id, '_stock');
            }

            if ($first_ava_var || $not_available_product_status === 'outofstock') {
                $this->update_price($product_id, $first_ava_var);
            }

            if (isset($product['sku_products']['variations']) && count($product['sku_products']['variations']) > 1) {
                foreach ($product['sku_products']['variations'] as &$var) {
                    $var['skip'] = in_array($var['id'], $product['skip_vars']);
                    $var['image'] = (!isset($var['image']) || in_array(md5($var['image']), $product['skip_images'])) ? '' : $var['image'];
                }
                $this->add_variation($product_id, $product);
            } else if (empty($product['sku_products']['variations'])) {
                if ($not_available_product_status === 'trash') {
                    $wc_product = wc_get_product($product_id);
                    $wc_product->delete();
                } else if ($not_available_product_status === 'outofstock') {
                    $wc_product = wc_get_product($product_id);
                    foreach ($wc_product->get_children() as $var_id) {
                        $var = wc_get_product($var_id);
                        A2W_Utils::delete_post_images($var_id);
                        $var->delete(true);
                    }
                    if ($wc_product->is_type('variable')) {
                        wp_set_object_terms($product_id, 'simple', 'product_type');
                    }
                }
            }

            wc_delete_product_transients($product_id);

            if (empty($params['skip_last_update'])) {
                update_post_meta($product_id, '_a2w_last_update', time());
            }

            do_action('a2w_upd_product', $product_id);

            return apply_filters('a2w_woocommerce_after_upd_product', $result, $product_id, $product, $params);
        }

        public function build_description($product_id, $product, &$loaded_images) {
            $a2w_use_external_image_urls = get_option('a2w_use_external_image_urls', false);

            $html = $product['description'];

            if (function_exists('mb_convert_encoding')) {
                $html = trim(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
            } else {
                $html = htmlspecialchars_decode(utf8_decode(htmlentities($html, ENT_COMPAT, 'UTF-8', false)));
            }

            $dom = new DOMDocument();
            @$dom->loadHTML($html);
            $dom->formatOutput = true;

            $elements = $dom->getElementsByTagName('img');
            for ($i = $elements->length; --$i >= 0;) {
                $e = $elements->item($i);
                if (in_array(md5($e->getAttribute('src')), $product['skip_images'])) {
                    $e->parentNode->removeChild($e);
                } else if (!$a2w_use_external_image_urls) {
                    $clean_img_src = A2W_Utils::clear_image_url($e->getAttribute('src'));
                    if (isset($loaded_images[$clean_img_src])) {
                        $attachment_id = $loaded_images[$clean_img_src];
                    } else {
                        $attachment_id = $this->attachment_model->create_attachment($product_id, $clean_img_src, isset($product['title']) && $product['title'] ? $product['title'] : "Product " . $product['id']);
                        $loaded_images[$clean_img_src] = $attachment_id;
                    }
                    $attachment_url = wp_get_attachment_url($attachment_id);
                    $e->setAttribute('src', $attachment_url);
                }
            }

            $html = preg_replace('~<(?:!DOCTYPE|/?(?:html|body))[^>]*>\s*~i', '', $dom->saveHTML());

            do {
                $tmp = $html;
                $html = preg_replace('#<([^ >]+)[^>]*>([[:space:]]|&nbsp;)*</\1>#', '', $html);
            } while ($html !== $tmp);

            return $html;
        }

        public function set_images($product_id, $thumb_url, $images, $update, &$loaded_images, $title = '') {

            if ($thumb_url && $thumb_url != 'empty' && (!get_post_thumbnail_id($product_id) || $update)) {
                try {
                    $clean_img_src = A2W_Utils::clear_image_url($thumb_url);
                    if (isset($loaded_images[$clean_img_src])) {
                        $thumb_id = $loaded_images[$clean_img_src];
                    } else {
                        $thumb_id = $this->attachment_model->create_attachment($product_id, $thumb_url);
                        $loaded_images[$clean_img_src] = $thumb_id;
                    }

                    set_post_thumbnail($product_id, $thumb_id);
                } catch (Exception $e) {
                    error_log($e->getMessage());
                }
            }

            if ($images) {
                if (!get_post_meta($product_id, '_product_image_gallery', true) || $update) {
                    //$images_limit = intval(get_option('a2w_import_product_images_limit'));

                    $image_gallery_ids = '';
                    $cnt = 0;
                    foreach ($images as $image_url) {
                        if ($image_url == $thumb_url) {
                            continue;
                        }

                        $cnt++;

                        //if (!$images_limit || ($cnt++) < $images_limit) {
                        try {
                            $clean_img_src = A2W_Utils::clear_image_url($image_url);
                            if (isset($loaded_images[$clean_img_src])) {
                                $new_image_gallery_id = $loaded_images[$clean_img_src];
                            } else {
                                $new_image_gallery_id = $this->attachment_model->create_attachment($product_id, $image_url, !empty($title) ? ($title . ' ' . $cnt) : null);
                                $loaded_images[$clean_img_src] = $new_image_gallery_id;
                            }

                            $image_gallery_ids .= $new_image_gallery_id . ',';
                        } catch (Exception $e) {
                            error_log($e->getMessage());
                        }
                        //}
                    }
                    update_post_meta($product_id, '_product_image_gallery', $image_gallery_ids);
                }
            }
        }

        public function update_price($product_id, $variation) {
            if ($variation) {
                $price = isset($variation['price']) ? $variation['price'] : 0;
                $regular_price = isset($variation['regular_price']) ? $variation['regular_price'] : $price;

                update_post_meta($product_id, '_aliexpress_regular_price', $regular_price);
                update_post_meta($product_id, '_aliexpress_price', $price);

                if (isset($variation['calc_price'])) {
                    $price = $variation['calc_price'];
                    $regular_price = isset($variation['calc_regular_price']) ? $variation['calc_regular_price'] : $price;
                }

                update_post_meta($product_id, '_regular_price', $regular_price);
                update_post_meta($product_id, '_sale_price', $price);
                update_post_meta($product_id, '_price', $price);
            } else {
                update_post_meta($product_id, '_price', 0);
                update_post_meta($product_id, '_regular_price', 0);
                delete_post_meta($product_id, '_sale_price');

                delete_post_meta($product_id, '_aliexpress_regular_price');
                delete_post_meta($product_id, '_aliexpress_price');
            }
        }

        private function set_attributes($product_id, $attributes) {
            if (defined('A2W_IMPORT_EXTENDED_ATTRIBUTE')) {
                $extended_attribute = filter_var(A2W_IMPORT_EXTENDED_ATTRIBUTE, FILTER_VALIDATE_BOOLEAN);
            } else {
                $extended_attribute = get_option('a2w_import_extended_attribute', false);
            }

            if ($extended_attribute) {
                $this->helper->set_woocommerce_attributes($attributes, $product_id);
            } else {
                $name = array_column($attributes, 'name');
                $count = array_count_values($name);
                $duplicate = array_unique(array_diff_assoc($name, array_unique($name)));
                $product_attributes = array();

                foreach ($attributes as $name => $value) {

                    if (isset($duplicate[$name + 1])) {
                        $val = array();
                        for ($i = 0; $i < $count[$value['name']]; $i++) {
                            $val[] = $attributes[$name + $i]['value'];
                        }
                        $product_attributes[str_replace(' ', '-', $value['name'])] = array(
                            'name' => $value['name'],
                            'value' => implode(', ', $val),
                            'position' => count($product_attributes),
                            'is_visible' => 1,
                            'is_variation' => 0,
                            'is_taxonomy' => 0
                        );
                    } elseif (!array_search($value['name'], $duplicate)) {
                        $product_attributes[str_replace(' ', '-', $value['name'])] = array(
                            'name' => $value['name'],
                            'value' => $value['value'],
                            'position' => count($product_attributes),
                            'is_visible' => 1,
                            'is_variation' => 0,
                            'is_taxonomy' => 0
                        );
                    }
                }

                update_post_meta($product_id, '_product_attributes', $product_attributes);
            }
        }

        private function build_categories($product) {
            if (isset($product['categories']) && $product['categories']) {
                return is_array($product['categories']) ? array_map('a2w_int_array_map', $product['categories']) : array(intval($product['categories']));
            } else if (isset($product['category_name']) && $product['category_name']) {
                $category_name = sanitize_text_field($product['category_name']);
                if ($category_name) {
                    $cat = get_terms('product_cat', array('name' => $category_name, 'hide_empty' => false));
                    if (empty($cat)) {
                        $cat = wp_insert_term($category_name, 'product_cat');
                        $cat_id = $cat['term_id'];
                    } else {
                        $cat_id = $cat->term_id;
                    }
                    return array($cat_id);
                }
            }
            return array();
        }

        private function add_variation($product_id, $product, &$loaded_images = array()) {
            global $wpdb;
            $result = array('state' => 'ok', 'message' => '');
            $variations = $product['sku_products'];
            if ($variations) {
                $tmp_product = wc_get_product($product_id);

                if ($variations && isset($variations['attributes']) && ($tmp_product->is_type('variable') || $tmp_product->is_type('simple'))) {
                    if ($tmp_product->is_type('simple')) {
                        wp_set_object_terms($product_id, 'variable', 'product_type');
                    }
                    $localCurrency = strtoupper(get_option('a2w_local_currency', ''));

                    if ($localCurrency === 'USD') {
                        $localCurrency = '';
                    }

                    if ($localCurrency) {
                        $currency_conversion_factor = 1;
                    } else {
                        $currency_conversion_factor = floatval(get_option('a2w_currency_conversion_factor', 1));
                    }

                    $attributes = array();
                    $used_variation_attributes = array();

                    $tmp_attributes = get_post_meta($product_id, '_product_attributes', true);
                    if (!$tmp_attributes) {
                        $tmp_attributes = array();
                    }

                    foreach ($tmp_attributes as $attr) {
                        if (!intval($attr['is_variation'])) {
                            $attributes[] = $attr;
                        }
                    }

                    $old_swatch_type_options = get_post_meta($product_id, '_swatch_type_options', true);
                    $old_swatch_type_options = $old_swatch_type_options ? $old_swatch_type_options : array();

                    $swatch_type_options = array();

                    foreach ($variations['attributes'] as $key => $attr) {
                        $attribute_taxonomies = $wpdb->get_var("SELECT * FROM {$wpdb->prefix}woocommerce_attribute_taxonomies WHERE attribute_name = '" . esc_sql(sanitize_title($attr['name'])) . "'");

                        $attr_tax = $this->helper->cleanTaxonomyName($attr['name'], $attribute_taxonomies);
                        $swatch_id = md5(sanitize_title($attr['name']));
                        $variations['attributes'][$key]['tax'] = $attr_tax;
                        $variations['attributes'][$key]['swatch_id'] = $swatch_id;
                        $variations['attributes'][$key]['attribute_taxonomies'] = $attribute_taxonomies;

                        $used_variation_attributes[$attr_tax] = array('attribute_taxonomies' => $attribute_taxonomies, 'values' => array());

                        $swatch_type_options[$swatch_id]['type'] = 'radio';
                        $swatch_type_options[$swatch_id]['layout'] = 'default';
                        $swatch_type_options[$swatch_id]['size'] = 'swatches_image_size';

                        $swatch_type_options[$swatch_id]['attributes'] = array();
                        $attr_values = array();
                        foreach ($attr['value'] as $val_key => $val) {
                            $has_variation = false;
                            foreach ($variations['variations'] as $variation) {
                                if (!$variation['skip']) {
                                    foreach ($variation['attributes'] as $va) {
                                        if ($va == $val['id']) {
                                            $has_variation = true;
                                        }
                                    }
                                }
                            }

                            if (!$has_variation) {
                                continue;
                            }

                            $attr_values[] = $val['name'];

                            $attr_image = "";
                            if (isset($val['thumb']) && $val['thumb']) {
                                $attr_image = $val['thumb'];
                            } else if (isset($val['image']) && $val['image']) {
                                $attr_image = $val['image'];
                            }

                            if ($attr_image || !empty($val['color'])) {
                                $swatch_type_options[$swatch_id]['type'] = 'product_custom';
                            }

                            $swatch_value_id = md5(sanitize_title(strtolower($val['name'])));

                            $variations['attributes'][$key]['value'][$val_key]['swatch_value_id'] = $swatch_value_id;

                            $swatch_type_options[$swatch_id]['attributes'][$swatch_value_id]['type'] = 'color';
                            $swatch_type_options[$swatch_id]['attributes'][$swatch_value_id]['color'] = empty($val['color']) ? '#FFFFFF' : $val['color'];
                            $swatch_type_options[$swatch_id]['attributes'][$swatch_value_id]['image'] = 0;

                            if ($attr_image) {
                                $swatch_type_options[$swatch_id]['attributes'][$swatch_value_id]['type'] = 'image';

                                $old_attachment_id = !empty($old_swatch_type_options[$swatch_id]['attributes'][$swatch_value_id]['image']) ? intval($old_swatch_type_options[$swatch_id]['attributes'][$swatch_value_id]['image']) : 0;
                                if (defined('A2W_RELOAD_ATTR_IMAGES') && A2W_RELOAD_ATTR_IMAGES) {
                                    if (intval($old_attachment_id) > 0) {
                                        wp_delete_attachment($old_attachment_id, true);
                                    }
                                    $attachment_id = $this->attachment_model->create_attachment($product_id, $attr_image);
                                } else {
                                    $attachment_id = $old_attachment_id ? $old_attachment_id : $this->attachment_model->create_attachment($product_id, $attr_image);
                                }
                                if (!empty($attachment_id)) {
                                    $swatch_type_options[$swatch_id]['attributes'][$swatch_value_id]['image'] = $attachment_id; //+    
                                } else if (!empty($old_attachment_id)) {
                                    $swatch_type_options[$swatch_id]['attributes'][$swatch_value_id]['image'] = $old_attachment_id; //+    
                                }
                            }
                        }

                        if ($attribute_taxonomies) {
                            $attributes[$attr_tax] = array(
                                'name' => $attr_tax,
                                'value' => '',
                                'position' => count($attributes),
                                'is_visible' => '0',
                                'is_variation' => '1',
                                'is_taxonomy' => '1'
                            );
                            $this->helper->add_attribute($product_id, $attr['name'], $attr_values);
                        } else {
                            $new_attr_values = array_unique($attr_values);
                            asort($new_attr_values);

                            $attributes[$attr_tax] = array(
                                'name' => $attr['name'],
                                'value' => implode("|", $new_attr_values),
                                'position' => count($attributes),
                                'is_visible' => '0',
                                'is_variation' => '1',
                                'is_taxonomy' => '0'
                            );
                        }
                    }

                    update_post_meta($product_id, '_product_attributes', $attributes);

                    $old_variations = get_posts(array('post_type' => 'product_variation', 'fields' => 'ids', 'numberposts' => 100, 'post_parent' => $product_id, 'meta_query' => array()));

                    $total_stock = 0;
                    $variation_images = array();
                    foreach ($variations['variations'] as $variation) {
                        if ($variation['skip']) {
                            continue;
                        }

                        $args = array('post_type' => 'product_variation', 'fields' => 'ids', 'numberposts' => 100, 'post_status' => 'any', 'post_parent' => $product_id, 'meta_query' => array(array('key' => 'external_variation_id', 'value' => $variation['id'])));
                        $old_vid = get_posts($args);
                        $old_vid = $old_vid ? $old_vid[0] : false;

                        if (!$old_vid) {
                            $tmp_variation = array(
                                'post_title' => 'Product #' . $product_id . ' Variation',
                                'post_content' => '',
                                'post_status' => 'publish',
                                'post_parent' => $product_id,
                                'post_type' => 'product_variation',
                                'meta_input' => array(
                                    'external_variation_id' => $variation['id'],
                                    '_sku' => $variation['sku'],
                                ),
                            );
                            $variation_id = wp_insert_post($tmp_variation);



                            $aliexpress_sku_props_id_arr = array();
                            foreach ($variation['attributes'] as $cur_var_attr) {
                                foreach ($variations['attributes'] as $attr) {
                                    if (isset($attr['value'][$cur_var_attr])) {
                                        $aliexpress_sku_props_id_arr[] = isset($attr['value'][$cur_var_attr]['original_id']) ? $attr['value'][$cur_var_attr]['original_id'] : $attr['value'][$cur_var_attr]['id'];
                                        break;
                                    }
                                }
                            }

                            $aliexpress_sku_props_id = $aliexpress_sku_props_id_arr ? implode(";", $aliexpress_sku_props_id_arr) : "";

                            if ($aliexpress_sku_props_id) {
                                update_post_meta($variation_id, '_aliexpress_sku_props', $aliexpress_sku_props_id);
                            }

                            // upload set variation image
                            if (isset($variation['image']) && $variation['image']) {
                                $clean_img_src = A2W_Utils::clear_image_url($variation['image']);
                                if (isset($loaded_images[$clean_img_src])) {
                                    $thumb_id = $loaded_images[$clean_img_src];
                                } else {
                                    $thumb_id = $this->attachment_model->create_attachment($variation_id, $variation['image']);
                                    $loaded_images[$clean_img_src] = $thumb_id;
                                }
                                set_post_thumbnail($variation_id, $thumb_id);
                            }

                            $variation_attribute_list = array();
                            foreach ($variation['attributes'] as $va) {
                                $attr_tax = "";
                                $attr_value = "";
                                foreach ($variations['attributes'] as $attr) {
                                    foreach ($attr['value'] as $val) {
                                        if ($val['id'] == $va) {
                                            $attr_tax = $attr['tax'];
                                            $attr_value = $attr['attribute_taxonomies'] ? $this->helper->cleanTaxonomyName($val['name'], false) : $val['name'];

                                            break;
                                        }
                                    }
                                    if ($attr_tax && $attr_value) {
                                        break;
                                    }
                                }

                                if ($attr_tax && $attr_value) {
                                    $variation_attribute_list[] = array('key' => ('attribute_' . $attr_tax), 'value' => $attr_value);

                                    if (isset($used_variation_attributes[$attr_tax])) {
                                        $used_variation_attributes[$attr_tax]['values'][] = $attr_value;
                                    }
                                }
                            }

                            foreach ($variation_attribute_list as $vai) {
                                update_post_meta($variation_id, $vai['key'], $vai['value']);
                            }
                        } else {
                            $variation_id = $old_vid;

                            $aliexpress_sku_props_id = get_post_meta($variation_id, '_aliexpress_sku_props', true);
                            $aliexpress_sku_props_id_arr = $aliexpress_sku_props_id ? explode(";", $aliexpress_sku_props_id) : array();

                            foreach ($used_variation_attributes as $attr_tax => $v) {
                                if ($attr_value = get_post_meta($variation_id, 'attribute_' . $attr_tax, true)) {
                                    $used_variation_attributes[$attr_tax]['values'][] = $attr_value;

                                    foreach ($aliexpress_sku_props_id_arr as $var_attr_id) {
                                        foreach ($variations['attributes'] as $external_attr) {
                                            if ($external_attr['tax'] === $attr_tax && isset($external_attr['value'][$var_attr_id])) {
                                                $new_swatch_value_id = md5(sanitize_title(strtolower($attr_value)));
                                                if ($new_swatch_value_id !== $external_attr['value'][$var_attr_id]['swatch_value_id'] && isset($swatch_type_options[$external_attr['swatch_id']]['attributes'][$external_attr['value'][$var_attr_id]['swatch_value_id']])) {
                                                    $swatch_type_options[$external_attr['swatch_id']]['attributes'][$new_swatch_value_id] = $swatch_type_options[$external_attr['swatch_id']]['attributes'][$external_attr['value'][$var_attr_id]['swatch_value_id']];
                                                    unset($swatch_type_options[$external_attr['swatch_id']]['attributes'][$external_attr['value'][$var_attr_id]['swatch_value_id']]);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        foreach ($old_variations as $k => $id) {
                            if (intval($id) == intval($variation_id)) {
                                unset($old_variations[$k]);
                            }
                        }

                        $tmp_quantity = intval($variation['quantity']);


                        if (get_option('woocommerce_manage_stock', 'no') === 'yes') {
                            update_post_meta($variation_id, '_manage_stock', 'yes');
                            update_post_meta($variation_id, '_stock_status', $tmp_quantity ? 'instock' : 'outofstock');

                            if (!$old_vid || !$product['disable_var_quantity_change']) {
                                update_post_meta($variation_id, '_stock', $tmp_quantity);
                            }
                        } else {
                            update_post_meta($variation_id, '_stock_status', $tmp_quantity ? 'instock' : 'outofstock');
                            delete_post_meta($variation_id, '_manage_stock');
                            delete_post_meta($variation_id, '_stock');
                        }

                        $total_stock += $tmp_quantity;

                        $this->update_price($variation_id, $variation);
                    }

                    // update priduct swatches
                    update_post_meta($product_id, '_swatch_type_options', $swatch_type_options); //+
                    update_post_meta($product_id, '_swatch_type', 'pickers'); //+
                    update_post_meta($product_id, '_swatch_size', 'swatches_image_size'); //+
                    //
                    // delete old variations
                    foreach ($old_variations as $id) {
                        wp_delete_post($id);
                    }

                    // for simple variations attributes, update atributes values (save only used values)
                    $need_update = false;
                    foreach ($used_variation_attributes as $attr_tax => $uva) {
                        if (!$uva['attribute_taxonomies']) {
                            $new_attr_values = array_unique($uva['values']);
                            asort($new_attr_values);
                            $attributes[$attr_tax]['value'] = implode("|", $new_attr_values);
                            $need_update = true;
                        }
                    }
                    if ($need_update) {
                        update_post_meta($product_id, '_product_attributes', $attributes);
                    }


                    // update total product stock
                    if (get_option('woocommerce_manage_stock', 'no') === 'yes') {
                        update_post_meta($product_id, '_manage_stock', 'yes');
                        update_post_meta($product_id, '_stock_status', intval($total_stock) ? 'instock' : 'outofstock');

                        if (!$product['disable_var_quantity_change']) {
                            update_post_meta($product_id, '_stock', intval($total_stock));
                        }
                    } else {
                        delete_post_meta($product_id, '_manage_stock');
                        delete_post_meta($product_id, '_stock_status');
                        delete_post_meta($product_id, '_stock');
                    }

                    WC_Product_Variable::sync($product_id);
                    WC_Product_Variable::sync_stock_status($product_id);
                }
            }
            return $result;
        }

        public function update_order($order_id, $data = array()) {
            $post = get_post($order_id);
            if ($post && $post->post_type === 'shop_order') {
                if (!empty($data['meta']) && is_array($data['meta'])) {
                    foreach ($data['meta'] as $key => $val) {
                        update_post_meta($order_id, $key, $val);
                    }
                }
            }
        }

        public function get_sorted_products_ids($sort_type, $ids_count, $compare = false) {
            $result = array();

            $ids0 = get_posts(array(
                'post_type' => 'product',
                'fields' => 'ids',
                'numberposts' => $ids_count,
                'meta_query' => array(
                    array(
                        'key' => '_a2w_import_type',
                        'value' => 'a2w'
                    ),
                    array(
                        'key' => $sort_type,
                        'compare' => 'NOT EXISTS'
                    )
                )
            ));

            foreach ($ids0 as $id) {
                $result[] = $id;
            }

            if (($ids_count - count($result)) > 0) {

                $meta_query = array(
                    array(
                        'key' => '_a2w_import_type',
                        'value' => 'a2w'
                    )
                );

                if ($compare) {
                    if (is_array($compare)) {
                        if (isset($compare['value']) && isset($compare['compare'])) {
                            $meta_query[] = array('key' => $sort_type, 'value' => $compare['value'], 'compare' => $compare['compare']);
                        }
                    } else {
                        $meta_query[] = array('key' => $sort_type, 'value' => $compare);
                    }
                }

                $res = get_posts(array(
                    'post_type' => 'product',
                    'fields' => 'ids',
                    'numberposts' => ($ids_count - count($result)),
                    'meta_query' => $meta_query,
                    'order' => 'ASC',
                    'orderby' => 'meta_value',
                    'meta_key' => $sort_type,
                    'suppress_filters' => false
                ));

                foreach ($res as $id) {
                    $result[] = $id;
                }
            }
            return $result;
        }

        function get_product_external_id($post_id) {
            $external_id = '';
            $post = get_post($post_id);
            if ($post) {
                if ($post->post_type === 'product') {
                    $external_id = get_post_meta($post_id, "_a2w_external_id", true);
                } else if ($post->post_type === 'product_variation') {
                    $external_id = get_post_meta($post->post_parent, "_a2w_external_id", true);
                }
            }
            return $external_id;
        }

        function get_product_by_post_id($post_id, $with_vars = true) {
            $product = array();

            $external_id = get_post_meta($post_id, "_a2w_external_id", true);
            if ($external_id) {
                $woocommerce_manage_stock = get_option('woocommerce_manage_stock', 'no');

                $product = array(
                    'id' => $external_id,
                    'post_id' => $post_id,
                    'url' => get_post_meta($post_id, "_a2w_original_product_url", true),
                    'affiliate_url' => get_post_meta($post_id, "_product_url", true),
                    'seller_url' => get_post_meta($post_id, "_a2w_seller_url", true),
                    'import_type' => get_post_meta($post_id, "_a2w_import_type", true),
                );

                $cats = wp_get_object_terms($post_id, 'product_cat');
                if (!is_wp_error($cats) && $cats) {
                    $product['category_id'] = $cats[0]->term_id;
                }

                $price = get_post_meta($post_id, "_aliexpress_price", true);
                $regular_price = get_post_meta($post_id, "_aliexpress_regular_price", true);
                if ($price || $regular_price) {
                    $product['price'] = $price ? $price : $regular_price;
                    $product['regular_price'] = $regular_price ? $regular_price : $price;
                    $product['discount'] = 100 - round($product['price'] * 100 / $product['regular_price']);
                }

                $price = get_post_meta($post_id, "_price", true);
                $regular_price = get_post_meta($post_id, "_regular_price", true);
                if ($price || $regular_price) {
                    $product['calc_price'] = $price ? $price : $regular_price;
                    $product['calc_regular_price'] = $regular_price ? $regular_price : $price;
                }

                if ($woocommerce_manage_stock === 'yes') {
                    $product['quantity'] = get_post_meta($post_id, "_stock", true);
                } else {
                    $product['quantity'] = get_post_meta($post_id, '_stock_status', true) === 'outofstock' ? 0 : 1;
                }

                $original_product_url = get_post_meta($post_id, "_a2w_original_product_url", true);
                $product['original_product_url'] = $original_product_url ? $original_product_url : 'www.aliexpress.com/item//' . $product['id'] . '.html';

                $availability_meta = get_post_meta($post_id, "_a2w_availability", true);
                $product['availability'] = $availability_meta ? filter_var($availability_meta, FILTER_VALIDATE_BOOLEAN) : true;

                $a2w_skip_meta = get_post_meta($post_id, "_a2w_skip_meta", true);

                $product['skip_vars'] = $a2w_skip_meta && !empty($a2w_skip_meta['skip_vars']) ? $a2w_skip_meta['skip_vars'] : array();
                $product['skip_images'] = $a2w_skip_meta && !empty($a2w_skip_meta['skip_images']) ? $a2w_skip_meta['skip_images'] : array();


                $product['disable_var_price_change'] = get_post_meta($post_id, "_a2w_disable_var_price_change", true);
                $product['disable_var_quantity_change'] = get_post_meta($post_id, "_a2w_disable_var_quantity_change", true);

                $product['sku_products']['attributes'] = array();
                $product['sku_products']['variations'] = array();
                if ($with_vars) {
                    $args = array('post_parent' => $post_id, 'post_type' => 'product_variation', 'numberposts' => -1, 'post_status' => 'any');
                    $variations = get_children($args);

                    if ($variations) {
                        foreach ($variations as $variation) {
                            $var = array('id' => get_post_meta($variation->ID, "external_variation_id", true), 'attributes' => array());

                            $price = get_post_meta($variation->ID, "_aliexpress_price", true);
                            $regular_price = get_post_meta($variation->ID, "_aliexpress_regular_price", true);
                            if ($price || $regular_price) {
                                $var['price'] = $price ? $price : $regular_price;
                                $var['regular_price'] = $regular_price ? $regular_price : $price;
                                $var['discount'] = 100 - round($var['price'] * 100 / $var['regular_price']);
                            }

                            $price = get_post_meta($variation->ID, "_price", true);
                            $regular_price = get_post_meta($variation->ID, "_regular_price", true);
                            if ($price || $regular_price) {
                                $var['calc_price'] = $price ? $price : $regular_price;
                                $var['calc_regular_price'] = $regular_price ? $regular_price : $price;
                            }
                            if ($woocommerce_manage_stock === 'yes') {
                                $var['quantity'] = get_post_meta($variation->ID, "_stock", true);
                            } else {
                                $var['quantity'] = get_post_meta($variation->ID, '_stock_status', true) === 'outofstock' ? 0 : 1;
                            }

                            $product['sku_products']['variations'][] = $var;
                        }
                    } else {
                        $var = array('id' => $external_id . "-1", 'attributes' => array());
                        if (!empty($product['price'])) {
                            $var['price'] = $product['price'];
                        }
                        if (!empty($product['regular_price'])) {
                            $var['regular_price'] = $product['regular_price'];
                        }
                        if (!empty($product['discount'])) {
                            $var['discount'] = $product['discount'];
                        }
                        if (!empty($product['calc_price'])) {
                            $var['calc_price'] = $product['calc_price'];
                        }
                        if (!empty($product['calc_regular_price'])) {
                            $var['calc_regular_price'] = $product['calc_regular_price'];
                        }
                        if (!empty($product['quantity'])) {
                            $var['quantity'] = $product['quantity'];
                        }

                        $product['sku_products']['variations'][] = $var;
                    }
                }
            }

            return $product;
        }

        public function get_product_tags() {
            $tags = get_terms('product_tag', array('hide_empty' => false));
            if (is_wp_error($tags)) {
                return array();
            } else {
                $result_tags = array();
                foreach ($tags as $tag) {
                    $result_tags[] = $tag->name;
                }
                return $result_tags;
            }
        }

        public function get_categories() {
            $categories = get_terms("product_cat", array('hide_empty' => 0, 'hierarchical' => true));
            if (is_wp_error($categories)) {
                return array();
            } else {
                $categories = json_decode(json_encode($categories), TRUE);
                $categories = $this->build_categories_tree($categories, 0);
                return $categories;
            }
        }

        private function build_categories_tree($all_cats, $parent_cat, $level = 1) {
            $res = array();
            foreach ($all_cats as $c) {
                if ($c['parent'] == $parent_cat) {
                    $c['level'] = $level;
                    $res[] = $c;
                    $child_cats = $this->build_categories_tree($all_cats, $c['term_id'], $level + 1);
                    if ($child_cats) {
                        $res = array_merge($res, $child_cats);
                    }
                }
            }
            return $res;
        }

    }

}
