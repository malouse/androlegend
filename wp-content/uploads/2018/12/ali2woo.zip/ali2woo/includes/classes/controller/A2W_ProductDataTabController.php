<?php
/**
 * Description of A2W_ProductDataTabController
 *
 * @author Andrey
 * 
 * @autoload: a2w_init
 */
if (!class_exists('A2W_ProductDataTabController')) {

    class A2W_ProductDataTabController {

        public $tab_class = '';
        public $tab_id = '';
        public $tab_title = '';
        public $tab_icon = '';

        public function __construct() {
            $this->tab_class = 'a2w_product_data';
            $this->tab_id = 'a2w_product_data';
            $this->tab_title = 'A2W Data';

            add_action('admin_head', array(&$this, 'on_admin_head'));

            add_action('woocommerce_product_write_panel_tabs', array(&$this, 'product_write_panel_tabs'), 99);
            add_action('woocommerce_product_data_panels', array(&$this, 'product_data_panel_wrap'), 99);
            add_action('woocommerce_process_product_meta', array(&$this, 'process_meta_box'), 1, 2);

            add_action('woocommerce_variation_options_pricing', array(&$this, 'variation_options_pricing'), 20, 3);
        }

        public function on_admin_head() {
            echo '<style type="text/css">#woocommerce-product-data ul.wc-tabs li.' . $this->tab_class . ' a::before {content: \'\f163\';}</style>';
        }

        public function product_write_panel_tabs() {
            ?>
            <li class="<?php echo $this->tab_class; ?>"><a href="#<?php echo $this->tab_id; ?>"><span><?php echo $this->tab_title; ?></span></a></li>
            <?php
        }

        public function product_data_panel_wrap() {
            ?>
            <div id="<?php echo $this->tab_id; ?>" class="panel <?php echo $this->tab_class; ?> woocommerce_options_panel wc-metaboxes-wrapper">
                <?php $this->render_product_tab_content(); ?>
            </div>
            <?php
        }

        public function render_product_tab_content() {
            global $post;

            echo '<div class="options_group">';
            woocommerce_wp_text_input(array(
                'id' => '_a2w_external_id',
                'value' => get_post_meta($post->ID, '_a2w_external_id', true),
                'label' => __('External Id', 'a2w'),
                'desc_tip' => true,
                'description' => __('External Aliexpress Product Id', 'a2w'),
            ));

            woocommerce_wp_text_input(array(
                'id' => '_a2w_orders_count',
                'value' => get_post_meta($post->ID, '_a2w_orders_count', true),
                'label' => __('Orders count', 'a2w'),
                'desc_tip' => true,
                'description' => __('Aliexpress orders count', 'a2w'),
            ));

            woocommerce_wp_checkbox(array(
                'id' => '_a2w_disable_var_price_change',
                'value' => get_post_meta($post->ID, '_a2w_disable_var_price_change', true) ? 'yes' : 'no',
                'label' => __('Disable price change?', 'a2w'),
                'description' => __('Disable variations price change', 'a2w'),
            ));
            woocommerce_wp_checkbox(array(
                'id' => '_a2w_disable_var_quantity_change',
                'value' => get_post_meta($post->ID, '_a2w_disable_var_quantity_change', true) ? 'yes' : 'no',
                'label' => __('Disable quantity change?', 'a2w'),
                'description' => __('Disable variations quantity change', 'a2w'),
            ));

            woocommerce_wp_text_input(array(
                'id' => '_a2w_product_url',
                'value' => get_post_meta($post->ID, '_product_url', true),
                'label' => __('Product url', 'a2w'),
                'desc_tip' => true,
                'description' => __('Product url', 'a2w'),
            ));

            woocommerce_wp_text_input(array(
                'id' => '_a2w_original_product_url',
                'value' => get_post_meta($post->ID, '_a2w_original_product_url', true),
                'label' => __('Original product url', 'a2w'),
                'desc_tip' => true,
                'description' => __('Original product url', 'a2w'),
            ));
            echo '</div>';

            echo '<div class="options_group">';
            woocommerce_wp_text_input(array(
                'id' => '_a2w_last_update',
                'value' => get_post_meta($post->ID, '_a2w_last_update', true),
                'label' => __('Last update', 'a2w'),
                'desc_tip' => true,
                'description' => __('Last update', 'a2w'),
            ));

            woocommerce_wp_text_input(array(
                'id' => '_a2w_reviews_last_update',
                'value' => get_post_meta($post->ID, '_a2w_reviews_last_update', true),
                'label' => __('Reviews last update', 'a2w'),
                'desc_tip' => true,
                'description' => __('Reviews last update', 'a2w'),
            ));

            woocommerce_wp_text_input(array(
                'id' => '_a2w_review_page',
                'value' => get_post_meta($post->ID, '_a2w_review_page', true),
                'label' => __('Review page', 'a2w'),
                'desc_tip' => true,
                'description' => __('Review page', 'a2w'),
            ));

            echo '</div>';
        }

        public function process_meta_box($post_id, $post) {
            if (!empty($_POST['_a2w_external_id'])) {
                update_post_meta($post_id, '_a2w_external_id', $_POST['_a2w_external_id']);
            } else {
                delete_post_meta($post_id, '_a2w_external_id');
            }

            if (!empty($_POST['_a2w_orders_count'])) {
                update_post_meta($post_id, '_a2w_orders_count', $_POST['_a2w_orders_count']);
            } else {
                delete_post_meta($post_id, '_a2w_orders_count');
            }

            if (!empty($_POST['_a2w_product_url'])) {
                update_post_meta($post_id, '_product_url', $_POST['_a2w_product_url']);
            } else {
                delete_post_meta($post_id, '_product_url');
            }

            if (!empty($_POST['_a2w_original_product_url'])) {
                update_post_meta($post_id, '_a2w_original_product_url', $_POST['_a2w_original_product_url']);
            } else {
                delete_post_meta($post_id, '_a2w_original_product_url');
            }

            update_post_meta($post_id, '_a2w_disable_var_price_change', !empty($_POST['_a2w_disable_var_price_change']) ? 1 : 0);

            if (!empty($_POST['_a2w_last_update'])) {
                update_post_meta($post_id, '_a2w_last_update', $_POST['_a2w_last_update']);
            } else {
                delete_post_meta($post_id, '_a2w_last_update');
            }
            if (!empty($_POST['_a2w_reviews_last_update'])) {
                update_post_meta($post_id, '_a2w_reviews_last_update', $_POST['_a2w_reviews_last_update']);
            } else {
                delete_post_meta($post_id, '_a2w_reviews_last_update');
            }
            if (!empty($_POST['_a2w_review_page'])) {
                update_post_meta($post_id, '_a2w_review_page', $_POST['_a2w_review_page']);
            } else {
                delete_post_meta($post_id, '_a2w_review_page');
            }
        }

        public function variation_options_pricing($loop, $variation_data, $variation) {
            if (!empty($variation_data['_aliexpress_regular_price']) || !empty($variation_data['_aliexpress_price'])) {
                echo '<p class="form-field form-row form-row-first">';
                if (!empty($variation_data['_aliexpress_regular_price'])) {
                    $label = sprintf(__('Aliexpress Regular price (%s)', 'a2w'), get_woocommerce_currency_symbol());

                    echo '<label style="cursor: inherit;">' . $label . ':</label>&nbsp;&nbsp;<label style="cursor: inherit;">' . wc_format_localized_price(is_array($variation_data['_aliexpress_regular_price']) ? $variation_data['_aliexpress_regular_price'][0] : $variation_data['_aliexpress_regular_price']) . '</label>';
                }
                echo '&nbsp;</p>';
                echo '<p class="form-field form-row form-row-last">';
                if (!empty($variation_data['_aliexpress_price'])) {
                    $label = sprintf(__('Aliexpress Sale price (%s)', 'a2w'), get_woocommerce_currency_symbol());
                    echo '<label style="cursor: inherit;">' . $label . ':</label>&nbsp;&nbsp;<label style="cursor: inherit;">' . wc_format_localized_price(is_array($variation_data['_aliexpress_price']) ? $variation_data['_aliexpress_price'][0] : $variation_data['_aliexpress_price']) . '</label>';
                }
                echo '&nbsp;</p>';
            }
        }

    }

}
