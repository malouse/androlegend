<?php

/**
 * Description of A2W_ProductServiceController
 *
 * @author Andrey
 * 
 * @autoload: a2w_init
 */
if (!class_exists('A2W_ProductServiceController')) {

    class A2W_ProductServiceController {

        public function __construct() {
            add_action("before_delete_post", array($this, 'delete_post_images_action'), 10, 1);
        }

        public function delete_post_images_action($post_id) {
            A2W_Utils::delete_post_images($post_id);
        }

    }

}
