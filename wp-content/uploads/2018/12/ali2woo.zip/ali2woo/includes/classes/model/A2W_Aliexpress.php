<?php

/**
 * Description of A2W_Aliexpress
 *
 * @author Andrey
 */
if (!class_exists('A2W_Aliexpress')) {

    class A2W_Aliexpress {

        private $product_import_model;

        function __construct() {
            $this->product_import_model = new A2W_ProductImport();
        }

        public function load_products($filter, $page = 1, $per_page = 20, $params = array()) {
            /** @var wpdb $wpdb */
            global $wpdb;

            $products_in_import = $this->product_import_model->get_product_id_list();

            $request_url = A2W_RequestHelper::build_request('get_products', array_merge(array('page' => $page, 'per_page' => $per_page), $filter));

            $request = a2w_remote_get($request_url);

            if (is_wp_error($request)) {
                $result = A2W_ResultBuilder::buildError($request->get_error_message());
            } else if (intval($request['response']['code']) != 200) {
                $result = A2W_ResultBuilder::buildError($request['response']['code'] . " " . $request['response']['message']);
            } else {
                $result = json_decode($request['body'], true);

                if (isset($result['state']) && $result['state'] !== 'error') {
                    $default_type = get_option('a2w_default_product_type', 'simple');
                    $default_status = get_option('a2w_default_product_status', 'publish');
                    foreach ($result['products'] as &$product) {
                        $product['post_id'] = $wpdb->get_var($wpdb->prepare("SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_a2w_external_id' AND meta_value='%s' LIMIT 1", $product['id']));
                        $product['import_id'] = in_array($product['id'], $products_in_import) ? $product['id'] : 0;
                        $product['product_type'] = $default_type;
                        $product['product_status'] = $default_status;

                        if (isset($filter['country']) && $filter['country']) {
                            $product['shipping_to_country'] = $filter['country'];
                        }
                    }
                }
            }
            return $result;
        }

        public function load_reviews($product_id, $page, $params = array()) {
            $request = a2w_remote_get("https://m.aliexpress.com/ajaxapi/EvaluationSearchAjax.do?type=all&index={$page}&pageSize=20&productId={$product_id}");
            
            if (is_wp_error($request)){
                $result = A2W_ResultBuilder::buildError($request->get_error_message());
            }else{
                $items = json_decode($request['body'], true);
                $result = A2W_ResultBuilder::buildOk(array('reviews'=>isset($items['evaViewList'])?$items['evaViewList']:array()));
            }
            return $result;
            
            /* old version
            
            $request_url = A2W_RequestHelper::build_request('get_reviews', array('page' => $page, 'product_id' => $product_id));

            $request = a2w_remote_get($request_url);

            if (is_wp_error($request)) {
                $result = A2W_ResultBuilder::buildError($request->get_error_message());
            } else {
                $result = json_decode($request['body'], true);

                if ($result['state'] == 'error') {
                    $result = A2W_ResultBuilder::buildError($request['response']['code'] . ' - ' . $request['response']['message']);
                }
            }

            return $result;
            */
        }

        public function load_product($product_id, $params = array()) {
            /** @var wpdb $wpdb */
            global $wpdb;
            $products_in_import = $this->product_import_model->get_product_id_list();

            $request_url = A2W_RequestHelper::build_request('get_product', array('product_id' => $product_id));

            $request = a2w_remote_get($request_url);

            if (is_wp_error($request)) {
                $result = A2W_ResultBuilder::buildError($request->get_error_message());
            } else {
                $result = json_decode($request['body'], true);

                if ($result['state'] !== 'error') {
                    $result['product']['post_id'] = $wpdb->get_var($wpdb->prepare("SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_a2w_external_id' AND meta_value='%s' LIMIT 1", $result['product']['id']));
                    $result['product']['import_id'] = in_array($result['product']['id'], $products_in_import) ? $result['product']['id'] : 0;
                    
                    if (get_option('a2w_use_random_stock', false)) {
                        $result['product']['disable_var_quantity_change'] = true;
                        foreach ($result['product']['sku_products']['variations'] as &$variation) {
                            $variation['original_quantity'] = intval($variation['quantity']);
                            $tmp_quantity = rand(intval(get_option('a2w_use_random_stock_min', 5)), intval(get_option('a2w_use_random_stock_max', 15)));
                            $tmp_quantity = ($tmp_quantity>$variation['original_quantity'])?$variation['original_quantity']:$tmp_quantity;
                            $variation['quantity'] = rand(intval(get_option('a2w_use_random_stock_min', 5)), intval(get_option('a2w_use_random_stock_max', 15)));
                        }
                    }

                    if (!get_option('a2w_not_import_description', false)) {
                        // alternativ method
                        //https://m.ru.aliexpress.com/item-desc/32797801052.html

                        $request_url = "https://" . (A2W_AliexpressLocalizator::getInstance()->language === 'en' ? "www" : A2W_AliexpressLocalizator::getInstance()->language) . ".aliexpress.com/getDescModuleAjax.htm?productId=" . $result['product']['id'] . "&t=" . (round(microtime(true), 3) * 1000);
                        $response = a2w_remote_get($request_url, array('cookies' => A2W_AliexpressLocalizator::getInstance()->getLocaleCookies()));
                        $body = $response['body'];
                        $desc_content = str_replace(array("window.productDescription='", "';"), '', $body);
                        if (function_exists('mb_convert_encoding')) {
                            $desc_content = trim(mb_convert_encoding($desc_content, 'HTML-ENTITIES', 'UTF-8'));
                        } else {
                            $desc_content = htmlspecialchars_decode(utf8_decode(htmlentities($desc_content, ENT_COMPAT, 'UTF-8', false)));
                        }
                        //$result['product']['description'] = $this->links_to_affiliate($desc_content);
                        $result['product']['description'] = $desc_content;

                        $result['product']['description'] = $this->clean_description($result['product']['description']);
                    } else {
                        $result['product']['description'] = '';
                    }

                    $tmp_all_images = A2W_Utils::get_all_images_from_product($result['product']);

                    $not_import_gallery_images = false;
                    $not_import_variant_images = false;
                    $not_import_description_images = get_option('a2w_not_import_description_images', false);

                    $result['product']['skip_images'] = array();
                    foreach ($tmp_all_images as $img_id => $img) {
                        if (!in_array($img_id, $result['product']['skip_images']) && (($not_import_gallery_images && $img['type'] === 'gallery') || ($not_import_variant_images && $img['type'] === 'variant') || ($not_import_description_images && $img['type'] === 'description'))) {
                            $result['product']['skip_images'][] = $img_id;
                        }
                    }

                    $request_url = 'https://m.aliexpress.com/ajaxapi/productItemDescripitonAjax.do?productId=' . $result['product']['id'] . '&lang=' . A2W_AliexpressLocalizator::getInstance()->language;
                    $response = a2w_remote_get($request_url, array('cookies' => A2W_AliexpressLocalizator::getInstance()->getLocaleCookies()));
                    if (!is_wp_error($response)) {
                        try {
                            $item = json_decode($response['body'], true);
                            if (!empty($item['descResult']['props'])) {
                                $result['product']['attribute'] = array();
                                foreach ($item['descResult']['props'] as $prop) {
                                    $result['product']['attribute'][] = array('name' => $prop['attrName'], 'value' => $prop['attrValue']);
                                }
                            }
                        } catch (Exception $e) {
                            
                        }
                    }
                }
            }

            return $result;
        }

        public function sync_products($product_ids, $params = array()) {
            $request_params = array('product_id' => implode(',', is_array($product_ids) ? $product_ids : array($product_ids)));
            if (!empty($params['manual_update'])) {
                $request_params['manual_update'] = 1;
            }
            $request_url = A2W_RequestHelper::build_request('sync_products', $request_params);

            $request = a2w_remote_get($request_url);
            if (is_wp_error($request)) {
                $result = A2W_ResultBuilder::buildError($request->get_error_message());
            } else {
                $result = json_decode($request['body'], true);
            }

            return $result;
        }

        public function load_shipping_info($product_id, $quantity, $country_code, $country_code_form = '') {
            $request_url = A2W_RequestHelper::build_request('get_shipping_info', array('product_id' => $product_id, 'quantity' => $quantity, 'country_code' => $country_code, 'country_code_from' => $country_code_form));

            $request = a2w_remote_get($request_url);
            if (is_wp_error($request)) {
                $result = A2W_ResultBuilder::buildError($request->get_error_message());
            } else {
                if (intval($request['response']['code']) == 200) {
                    $result = json_decode($request['body'], true);
                } else {
                    $result = A2W_ResultBuilder::buildError($request['response']['code'] . ' - ' . $request['response']['message']);
                }
            }

            return $result;
        }

        public static function clean_description($description) {
            $html = $description;

            if (function_exists('mb_convert_encoding')) {
                $html = trim(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
            } else {
                $html = htmlspecialchars_decode(utf8_decode(htmlentities($html, ENT_COMPAT, 'UTF-8', false)));
            }

            $dom = new DOMDocument();
            @$dom->loadHTML($html);
            $dom->formatOutput = true;

            $tags = apply_filters('a2w_clean_description_tags', array('script', 'head', 'meta', 'style', 'map', 'noscript', 'object', 'iframe'));

            foreach ($tags as $tag) {
                $elements = $dom->getElementsByTagName($tag);
                for ($i = $elements->length; --$i >= 0;) {
                    $e = $elements->item($i);
                    if ($tag == 'a') {
                        while ($e->hasChildNodes()) {
                            $child = $e->removeChild($e->firstChild);
                            $e->parentNode->insertBefore($child, $e);
                        }
                        $e->parentNode->removeChild($e);
                    } else {
                        $e->parentNode->removeChild($e);
                    }
                }
            }
            
            if(!in_array('img', $tags)){
                $elements = $dom->getElementsByTagName('img');
                for ($i = $elements->length; --$i >= 0;) {
                    $e = $elements->item($i);
                    $e->setAttribute('src', A2W_Utils::clear_image_url($e->getAttribute('src'), '?descimg=1'));
                }
            }
            


            $html = preg_replace('~<(?:!DOCTYPE|/?(?:html|body))[^>]*>\s*~i', '', $dom->saveHTML());

            $html = preg_replace('/(<[^>]+) style=".*?"/i', '$1', $html);
            $html = preg_replace('/(<[^>]+) class=".*?"/i', '$1', $html);
            $html = preg_replace('/(<[^>]+) width=".*?"/i', '$1', $html);
            $html = preg_replace('/(<[^>]+) height=".*?"/i', '$1', $html);
            $html = preg_replace('/(<[^>]+) alt=".*?"/i', '$1', $html);
            $html = preg_replace('/^<!DOCTYPE.+?>/', '$1', str_replace(array('<html>', '</html>', '<body>', '</body>'), '', $html));
            $html = preg_replace("/<\/?div[^>]*\>/i", "", $html);

            $html = preg_replace('#(<a.*?>).*?(</a>)#', '$1$2', $html);
            $html = preg_replace('/<a[^>]*>(.*)<\/a>/iU', '', $html);
            $html = preg_replace("/<\/?h1[^>]*\>/i", "", $html);
            $html = preg_replace("/<\/?strong[^>]*\>/i", "", $html);
            $html = preg_replace("/<\/?span[^>]*\>/i", "", $html);

            //$html = str_replace(' &nbsp; ', '', $html);
            $html = str_replace('&nbsp;', ' ', $html);
            $html = str_replace('\t', ' ', $html);
            $html = str_replace('  ', ' ', $html);


            $html = preg_replace("/http:\/\/g(\d+)\.a\./i", "https://ae$1.", $html);

            $pattern = "/<[^\/>]*>([\s]?)*<\/[^>]*>/";
            $html = preg_replace($pattern, '', $html);

            $html = str_replace(array('<img', '<table'), array('<img class="img-responsive"', '<table class="table table-bordered'), $html);
            $html = force_balance_tags($html);

            do {
                $tmp = $html;
                $html = preg_replace('#<([^ >]+)[^>]*>([[:space:]]|&nbsp;)*</\1>#', '', $html);
            } while ($html !== $tmp);

            return $html;
        }

        public function get_affiliate_urls($urls) {
            $urls_str = "";
            if (is_array($urls)) {
                $urls_str = implode(',', $urls);
            } else {
                $urls_str = strval($urls);
            }
            $account = A2W_Account::getInstance();
            $request_url = "http://gw.api.alibaba.com/openapi/param2/2/portals.open/api.getPromotionLinks/{$account->appkey}?fields=&trackingId={$account->trackingid}&urls={$urls_str}";

            $request = a2w_remote_get($request_url);

            $data = json_decode($request['body'], true);
            if (isset($data['errorCode']) && $data['errorCode'] == 20010000) {
                return $data['result']['promotionUrls'];
            } else if (isset($data['errorCode']) && $data['errorCode'] == 20030060) {
                return 'Tracking ID input parameter error. Please input correct Tracking ID in the WooImporter Settings.';
            } else {
                return "get_affiliate_goods: error " . $data['errorCode'];
            }
        }

        public function links_to_affiliate($content) {
            $hrefs = array();
            $dom = new DOMDocument();
            @$dom->loadHTML($content);
            $dom->formatOutput = true;
            $tags = $dom->getElementsByTagName('a');
            foreach ($tags as $tag) {
                $hrefs[] = $tag->getAttribute('href');
            }

            try {
                if ($hrefs) {
                    $promotionUrls = $this->get_affiliate_urls($hrefs);
                    if (is_array($promotionUrls)) {
                        foreach ($promotionUrls as $link) {
                            $content = str_replace($link['url'], $link['promotionUrl'], $content);
                        }
                    }
                }
            } catch (Exception $e) {
                
            }
            return $content;
        }

    }

}