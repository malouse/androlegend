<?php

/**
 * Description of A2W_SettingPage
 *
 * @author Andrey
 * 
 * @autoload: a2w_init 
 */
if (!class_exists('A2W_SettingPageController')) {


    class A2W_SettingPageController extends A2W_AbstractAdminPage {

        private $product_import_model;
        private $woocommerce_model;

        public function __construct() {
            parent::__construct("Setting", "Setting", 'manage_options', 'a2w_setting', 30);

            $this->product_import_model = new A2W_ProductImport();
            $this->woocommerce_model = new A2W_Woocommerce();

            add_action('wp_ajax_a2w_update_price_rules', array($this, 'ajax_update_price_rules'));

            add_action('wp_ajax_a2w_apply_pricing_rules', array($this, 'ajax_apply_pricing_rules'));

            add_action('wp_ajax_a2w_update_phrase_rules', array($this, 'ajax_update_phrase_rules'));

            add_action('wp_ajax_a2w_apply_phrase_rules', array($this, 'ajax_apply_phrase_rules'));

            add_action('wp_ajax_a2w_get_status_apply_phrase_rules', array($this, 'ajax_get_status_apply_phrase_rules'));


            add_action('wp_ajax_a2w_calc_external_images_count', array($this, 'ajax_calc_external_images_count'));
            add_action('wp_ajax_a2w_calc_external_images', array($this, 'ajax_calc_external_images'));
            add_action('wp_ajax_a2w_load_external_image', array($this, 'ajax_load_external_image'));

            add_filter('a2w_setting_view', array($this, 'setting_view'));

            add_filter('a2w_configure_lang_data', array($this, 'configure_lang_data'));
        }

        function configure_lang_data($lang_data) {
            if ($this->is_current_page()) {
                $lang_data = array(
                    'process_loading_d_of_d_erros_d' => _x('Process loading %d of %d. Errors: %d.', 'Status', 'a2w'),
                    'load_button_text' => _x('Load %d images', 'Status', 'a2w'),
                    'all_images_loaded_text' => _x('All images loaded', 'Status', 'a2w'),
                );
            }
            return $lang_data;
        }

        public function render($params = array()) {
            $current_module = isset($_REQUEST['subpage']) ? $_REQUEST['subpage'] : 'common';

            $this->model_put("modules", $this->getModules());
            $this->model_put("current_module", $current_module);

            $this->include_view(array("settings/settings_head.php", apply_filters('a2w_setting_view', $current_module), "settings/settings_footer.php"));
        }

        public function getModules() {
            return apply_filters('a2w_setting_modules', array(
                array('id' => 'common', 'name' => __('Common settings', 'a2w')),
                array('id' => 'account', 'name' => __('Account settings', 'a2w')),
                array('id' => 'price_formula', 'name' => __('Pricing Rules', 'a2w')),
                array('id' => 'reviews', 'name' => __('Reviews settings', 'a2w')),
                array('id' => 'shipping', 'name' => __('Shipping settings', 'a2w')),
                array('id' => 'phrase_filter', 'name' => __('Phrase Filtering', 'a2w')),
            ));
        }

        public function setting_view($current_module) {
            $view = "";
            switch ($current_module) {
                case 'common':
                    $view = $this->common_handle();
                    break;
                case 'account':
                    $view = $this->account_handle();
                    break;
                case 'price_formula':
                    $view = $this->price_formula();
                    break;
                case 'reviews':
                    $view = $this->reviews();
                    break;
                case 'shipping':
                    $view = $this->shipping();
                    break;
                case 'phrase_filter':
                    $view = $this->phrase_filter();
                    break;
            }
            return $view;
        }

        private function common_handle() {
            if (isset($_POST['setting_form'])) {
                update_option('a2w_item_purchase_code', isset($_POST['a2w_item_purchase_code']) ? wp_unslash($_POST['a2w_item_purchase_code']) : '');
                update_option('a2w_envato_personal_token', isset($_POST['a2w_envato_personal_token']) ? wp_unslash($_POST['a2w_envato_personal_token']) : '');

                update_option('a2w_import_language', isset($_POST['a2w_import_language']) ? wp_unslash($_POST['a2w_import_language']) : 'en');
                update_option('a2w_local_currency', isset($_POST['a2w_local_currency']) ? wp_unslash($_POST['a2w_local_currency']) : 'usd');
                update_option('a2w_default_product_type', isset($_POST['a2w_default_product_type']) ? wp_unslash($_POST['a2w_default_product_type']) : 'simple');
                update_option('a2w_default_product_status', isset($_POST['a2w_default_product_status']) ? wp_unslash($_POST['a2w_default_product_status']) : 'publish');

                //remove saved shipping meta
                A2W_ShippingMeta::clear_in_all_product();

                update_option('a2w_currency_conversion_factor', isset($_POST['a2w_currency_conversion_factor']) ? wp_unslash($_POST['a2w_currency_conversion_factor']) : '1');
                update_option('a2w_import_product_images_limit', isset($_POST['a2w_import_product_images_limit']) && intval($_POST['a2w_import_product_images_limit']) ? intval($_POST['a2w_import_product_images_limit']) : '');
                update_option('a2w_import_extended_attribute', isset($_POST['a2w_import_extended_attribute']) ? 1 : 0);
                update_option('a2w_use_external_image_urls', isset($_POST['a2w_use_external_image_urls']));
                update_option('a2w_not_import_attributes', isset($_POST['a2w_not_import_attributes']));
                update_option('a2w_not_import_description', isset($_POST['a2w_not_import_description']));
                update_option('a2w_not_import_description_images', isset($_POST['a2w_not_import_description_images']));

                update_option('a2w_use_random_stock', isset($_POST['a2w_use_random_stock']));
                if (isset($_POST['a2w_use_random_stock'])) {
                    $min_stock = (!empty($_POST['a2w_use_random_stock_min']) && intval($_POST['a2w_use_random_stock_min']) > 0) ? intval($_POST['a2w_use_random_stock_min']) : 1;
                    $max_stock = (!empty($_POST['a2w_use_random_stock_max']) && intval($_POST['a2w_use_random_stock_max']) > 0) ? intval($_POST['a2w_use_random_stock_max']) : 1;

                    if ($min_stock > $max_stock) {
                        $min_stock = $min_stock + $max_stock;
                        $max_stock = $min_stock - $max_stock;
                        $min_stock = $min_stock - $max_stock;
                    }
                    update_option('a2w_use_random_stock_min', $min_stock);
                    update_option('a2w_use_random_stock_max', $max_stock);
                }

                update_option('a2w_auto_update', isset($_POST['a2w_auto_update']));
                update_option('a2w_not_available_product_status', isset($_POST['a2w_not_available_product_status']) ? wp_unslash($_POST['a2w_not_available_product_status']) : 'trash');

                update_option('a2w_fulfillment_prefship', isset($_POST['a2w_fulfillment_prefship']) ? wp_unslash($_POST['a2w_fulfillment_prefship']) : 'ePacket');
                update_option('a2w_fulfillment_phone_code', isset($_POST['a2w_fulfillment_phone_code']) ? wp_unslash($_POST['a2w_fulfillment_phone_code']) : '');
                update_option('a2w_fulfillment_phone_number', isset($_POST['a2w_fulfillment_phone_number']) ? wp_unslash($_POST['a2w_fulfillment_phone_number']) : '');
                update_option('a2w_fulfillment_custom_note', isset($_POST['a2w_fulfillment_custom_note']) ? wp_unslash($_POST['a2w_fulfillment_custom_note']) : '');
            }
            return "settings/common.php";
        }

        private function account_handle() {
            $account = A2W_Account::getInstance();

            if (isset($_POST['setting_form'])) {
                $account->use_custom_account(isset($_POST['a2w_use_custom_account']));
                if ($account->custom_account) {
                    $account->save_account(isset($_POST['a2w_appkey']) ? $_POST['a2w_appkey'] : '', isset($_POST['a2w_trackingid']) ? $_POST['a2w_trackingid'] : '');
                }
            }

            $this->model_put("account", $account);

            return "settings/account.php";
        }

        private function price_formula() {
            $formulas = A2W_PriceFormula::load_formulas();

            if ($formulas) {
                $add_formula = new A2W_PriceFormula();
                $add_formula->min_price = floatval($formulas[count($formulas) - 1]->max_price) + 0.01;
                $formulas[] = $add_formula;
                $this->model_put("formulas", $formulas);
            } else {
                $this->model_put("formulas", A2W_PriceFormula::get_default_formulas());
            }

            $this->model_put("default_formula", A2W_PriceFormula::get_default_formula());

            $this->model_put('cents', get_option('a2w_price_cents', -1));
            $this->model_put('compared_cents', get_option('a2w_price_compared_cents', -1));

            return "settings/price_formula.php";
        }

        private function reviews() {
            if (isset($_POST['setting_form'])) {

                update_option('a2w_review_status', isset($_POST['a2w_review_status']));
                update_option('a2w_review_translated', isset($_POST['a2w_review_translated']));
                update_option('a2w_review_avatar_import', isset($_POST['a2w_review_avatar_import']));

                update_option('a2w_review_schedule_load_period', 'a2w_15_mins');

                update_option('a2w_review_max_per_product', isset($_POST['a2w_review_max_per_product']) ? wp_unslash($_POST['a2w_review_max_per_product']) : '');

                /*
                  update_option('a2w_review_schedule_load_period', isset($_POST['a2w_review_schedule_load_period']) ? $_POST['a2w_review_schedule_load_period'] : 'daily');

                  if (isset($_POST['a2w_review_update_per_schedule'])) {
                  $value = intval($_POST['a2w_review_update_per_schedule']);
                  if ($value >= A2W_REVIEW_MAX_PRODUCT_PER_SHEDULE)
                  $value = A2W_REVIEW_MAX_PRODUCT_PER_SHEDULE;
                  if ($value < 1)
                  $value = 1;

                  update_option('a2w_review_update_per_schedule', $value);
                  }
                 */
                /*
                  $schedule_review_status = get_option('a2w_review_status', false);
                  if ($schedule_review_status) {
                  wp_schedule_event(time(), get_option('a2w_review_schedule_load_period', 'daily'), 'a2w_schedule_review_event');
                  } else {
                  wp_clear_scheduled_hook('a2w_schedule_review_event');
                  } */

                //todo:
                if (isset($_POST['a2w_review_allow_country'])) {
                    $value = trim($_POST['a2w_review_allow_country']);
                    if (!empty($value)) {
                        $value = str_replace(" ", "", $_POST['a2w_review_allow_country']);
                        $value = strtoupper($value);
                    }

                    update_option('a2w_review_allow_country', $value);
                }

                //raiting fields
                $raiting_from = 1;
                $raiting_to = 5;
                if (isset($_POST['a2w_review_raiting_from']))
                    $raiting_from = intval($_POST['a2w_review_raiting_from']);

                if (isset($_POST['a2w_review_raiting_to']))
                    $raiting_to = intval($_POST['a2w_review_raiting_to']);

                if ($raiting_from >= 5)
                    $raiting_from = 5;
                if ($raiting_from < 1 || $raiting_from > $raiting_to)
                    $raiting_from = 1;

                if ($raiting_to >= 5)
                    $raiting_to = 5;
                if ($raiting_to < 1)
                    $raiting_to = 1;

                update_option('a2w_review_raiting_from', $raiting_from);
                update_option('a2w_review_raiting_to', $raiting_to);


                //update more field
                //update_option('a2w_review_load_more', isset($_POST['a2w_review_load_more']));
                update_option('a2w_review_load_attributes', isset($_POST['a2w_review_load_attributes']));
                update_option('a2w_review_show_image_list', isset($_POST['a2w_review_show_image_list']));

                /* $auto_load_status = get_option('a2w_review_status', false);
                  if ($auto_load_status) {
                  wp_clear_scheduled_hook('a2w_schedule_review_event');
                  wp_schedule_event(time(), get_option('a2w_review_schedule_load_period', 'a2w_15_mins'), 'a2w_schedule_review_event');
                  } else {
                  wp_clear_scheduled_hook('a2w_schedule_review_event');
                  } */


                if (isset($_FILES) && isset($_FILES['a2w_review_noavatar_photo']) && 0 === $_FILES['a2w_review_noavatar_photo']['error']) {

                    if (!function_exists('wp_handle_upload'))
                        require_once( ABSPATH . 'wp-admin/includes/file.php' );

                    $uploadedfile = $_FILES['a2w_review_noavatar_photo'];
                    $upload_overrides = array('test_form' => false);
                    $movefile = wp_handle_upload($uploadedfile, $upload_overrides);
                    if ($movefile) {
                        update_option('a2w_review_noavatar_photo', $movefile['url']);
                    } else {
                        echo "Possible file upload attack!\n";
                    }
                }
            }
            return "settings/reviews.php";
        }

        private function shipping() {
            if (isset($_POST['setting_form'])) {
                update_option('a2w_aliship_shipto', isset($_POST['a2w_aliship_shipto']) ? wp_unslash($_POST['a2w_aliship_shipto']) : 'US');
                update_option('a2w_aliship_frontend', isset($_POST['a2w_aliship_frontend']));
            }

            $countryModel = new A2W_Country();

            $this->model_put("shipping_countries", $countryModel->get_countries());

            return "settings/shipping.php";
        }

        private function phrase_filter() {
            $phrases = A2W_PhraseFilter::load_phrases();

            if ($phrases) {
                $this->model_put("phrases", $phrases);
            } else {
                $this->model_put("phrases", array());
            }

            return "settings/phrase_filter.php";
        }

        public function ajax_update_phrase_rules() {
            a2w_init_error_handler();

            $result = A2W_ResultBuilder::buildOk();
            try {

                A2W_PhraseFilter::deleteAll();

                if (isset($_POST['phrases'])) {
                    foreach ($_POST['phrases'] as $phrase) {
                        $filter = new A2W_PhraseFilter($phrase);
                        $filter->save();
                    }
                }

                $result = A2W_ResultBuilder::buildOk(array('phrases' => A2W_PhraseFilter::load_phrases()));

                restore_error_handler();
            } catch (Exception $e) {
                $result = A2W_ResultBuilder::buildError($e->getMessage());
            }

            echo json_encode($result);

            wp_die();
        }

        /*
          public function ajax_get_status_apply_phrase_rules(){

          a2w_init_error_handler();

          try {
          //get review status
          $filter_info = A2W_PhraseFilter::apply_filter_to_reviews(true);

          $params = array();
          if ($filter_info && isset($filter_info['id_list']) && isset($filter_info['init_count'])
          && count($filter_info['id_list']) > 0 && count($filter_info['init_count']) > 0){
          $percent_val = 100 - count($filter_info['id_list']) * 100 / $filter_info['init_count'];
          $params['review_valuenow'] = round($percent_val, 2);

          }


          //get product status

          //get shipping status

          $result = A2W_ResultBuilder::buildOk($params);
          restore_error_handler();
          } catch (Exception $e) {
          $result = A2W_ResultBuilder::buildError($e->getMessage());
          }

          echo json_encode($result);

          wp_die();
          }
         */

        public function ajax_apply_phrase_rules() {
            a2w_init_error_handler();

            $result = A2W_ResultBuilder::buildOk();
            try {

                $type = isset($_POST['type']) ? $_POST['type'] : false;
                $scope = isset($_POST['scope']) ? $_POST['scope'] : false;

                if ($type === 'products' || $type === 'all_types') {
                    if ($scope === 'all' || $scope === 'import') {
                        $products = $this->product_import_model->get_product_list(false);

                        foreach ($products as $product) {

                            $product = A2W_PhraseFilter::apply_filter_to_product($product);
                            $this->product_import_model->upd_product($product);
                        }
                    }
                    // }

                    if ($scope === 'all' || $scope === 'shop') {
                        //todo: update attributes as well
                        A2W_PhraseFilter::apply_filter_to_products();
                    }
                }

                if ($type === 'all_types' || $type === 'reviews') {

                    A2W_PhraseFilter::apply_filter_to_reviews();
                }

                if ($type === 'all_types' || $type === 'shippings') {
                    
                }
                restore_error_handler();
            } catch (Exception $e) {
                $result = A2W_ResultBuilder::buildError($e->getMessage());
            }

            echo json_encode($result);

            wp_die();
        }

        public function ajax_update_price_rules() {
            a2w_init_error_handler();

            $result = A2W_ResultBuilder::buildOk();
            try {

                $use_extended_price_markup = isset($_POST['use_extended_price_markup']) ? filter_var($_POST['use_extended_price_markup'], FILTER_VALIDATE_BOOLEAN) : false;
                $use_compared_price_markup = isset($_POST['use_compared_price_markup']) ? filter_var($_POST['use_compared_price_markup'], FILTER_VALIDATE_BOOLEAN) : false;

                update_option('a2w_price_cents', isset($_POST['cents']) && intval($_POST['cents']) > -1 && intval($_POST['cents']) <= 99 ? intval(wp_unslash($_POST['cents'])) : -1);
                if ($use_compared_price_markup)
                    update_option('a2w_price_compared_cents', isset($_POST['compared_cents']) && intval($_POST['compared_cents']) > -1 && intval($_POST['compared_cents']) <= 99 ? intval(wp_unslash($_POST['compared_cents'])) : -1);
                else
                    update_option('a2w_price_compared_cents', -1);

                update_option('a2w_use_extended_price_markup', $use_extended_price_markup);
                update_option('a2w_use_compared_price_markup', $use_compared_price_markup);

                if (isset($_POST['rules'])) {
                    A2W_PriceFormula::deleteAll();
                    foreach ($_POST['rules'] as $rule) {
                        $formula = new A2W_PriceFormula($rule);
                        $formula->save();
                    }
                }

                if (isset($_POST['default_rule'])) {
                    A2W_PriceFormula::set_default_formula(new A2W_PriceFormula($_POST['default_rule']));
                }

                $result = A2W_ResultBuilder::buildOk(array('rules' => A2W_PriceFormula::load_formulas(), 'default_rule' => A2W_PriceFormula::get_default_formula(), 'use_extended_price_markup' => $use_extended_price_markup, 'use_compared_price_markup' => $use_compared_price_markup));

                restore_error_handler();
            } catch (Exception $e) {
                $result = A2W_ResultBuilder::buildError($e->getMessage());
            }

            echo json_encode($result);

            wp_die();
        }

        public function ajax_apply_pricing_rules() {
            a2w_init_error_handler();

            $result = A2W_ResultBuilder::buildOk();
            try {

                $type = isset($_POST['type']) ? $_POST['type'] : false;
                $scope = isset($_POST['scope']) ? $_POST['scope'] : false;

                if ($scope === 'all' || $scope === 'import') {
                    $products = $this->product_import_model->get_product_list(false);

                    foreach ($products as $product) {

                        if (!isset($product['disable_var_price_change']) || !$product['disable_var_price_change']) {
                            $product = A2W_PriceFormula::apply_formula($product, 2, $type);
                            $this->product_import_model->upd_product($product);
                        }
                    }
                }

                if ($scope === 'all' || $scope === 'shop') {
                    $product_ids = $this->woocommerce_model->get_sorted_products_ids("_a2w_last_update", 10000);
                    foreach ($product_ids as $product_id) {
                        $product = $this->woocommerce_model->get_product_by_post_id($product_id);
                        if (!isset($product['disable_var_price_change']) || !$product['disable_var_price_change']) {
                            $product = A2W_PriceFormula::apply_formula($product, 2, $type);
                            if (isset($product['sku_products']['variations']) && count($product['sku_products']['variations']) > 0) {
                                $this->woocommerce_model->update_price($product_id, $product['sku_products']['variations'][0]);

                                foreach ($product['sku_products']['variations'] as $var) {
                                    $variation_id = get_posts(array('post_type' => 'product_variation', 'fields' => 'ids', 'numberposts' => 100, 'post_parent' => $product_id, 'meta_query' => array(array('key' => 'external_variation_id', 'value' => $var['id']))));
                                    $variation_id = $variation_id ? $variation_id[0] : false;
                                    if ($variation_id) {
                                        $this->woocommerce_model->update_price($variation_id, $var);
                                    }
                                }
                                wc_delete_product_transients($product_id);
                            }
                            //$this->woocommerce_model->upd_product($product_id, $product, array('skip_last_update'=>true));
                        }
                    }
                }

                restore_error_handler();
            } catch (Exception $e) {
                $result = A2W_ResultBuilder::buildError($e->getMessage());
            }

            echo json_encode($result);

            wp_die();
        }

        public function ajax_calc_external_images_count() {
            echo json_encode(A2W_ResultBuilder::buildOk(array('total_images' => A2W_Attachment::calc_total_external_images())));
            wp_die();
        }

        public function ajax_calc_external_images() {
            $page_size = isset($_POST['page_size']) && intval($_POST['page_size']) > 0 ? intval($_POST['page_size']) : 1000;
            $result = A2W_ResultBuilder::buildOk(array('ids' => A2W_Attachment::find_external_images($page_size)));
            echo json_encode($result);
            wp_die();
        }

        public function ajax_load_external_image() {
            global $wpdb;

            a2w_init_error_handler();

            $attachment_model = new A2W_Attachment('local');

            $image_id = isset($_POST['id']) && intval($_POST['id']) > 0 ? intval($_POST['id']) : 0;

            if ($image_id) {
                try {
                    $attachment_model->load_external_image($image_id);

                    $result = A2W_ResultBuilder::buildOk();
                } catch (Exception $e) {
                    $result = A2W_ResultBuilder::buildError($e->getMessage());
                }
            } else {
                $result = A2W_ResultBuilder::buildError("load_external_image: waiting for ID...");
            }


            echo json_encode($result);
            wp_die();
        }

    }

}
