<?php

/**
 * Description of A2W_Migrate
 *
 * @author Andrey
 * 
 * @autoload: a2w_init
 */

if (!class_exists('A2W_Migrate')) {

    class A2W_Migrate {
        public function __construct() {
            $this->migrate();
        }
        
        public function migrate(){
            $cur_version = get_option('a2w_db_version', '');
            if(version_compare($cur_version, "1.2.0", '<')) {
                $this->migrate_to_120();
            }
            
            if(version_compare($cur_version, "1.2.1", '<')) {
                $this->migrate_to_121();
            }
            
            if(version_compare($cur_version, A2W()->version, '<')) {
                update_option('a2w_db_version', A2W()->version);
            }
        }
        
        private function migrate_to_120(){
            error_log('migrate to 1.2.0');
            
            global $wpdb;
            
            $wpdb->query("UPDATE {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE pm1.meta_key='import_type' and pm1.meta_value='a2w') src SET pm2.meta_key='_a2w_external_id' WHERE pm2.post_id=src.post_id and pm2.meta_key='external_id'");
            
            $wpdb->query("UPDATE {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE pm1.meta_key='import_type' and pm1.meta_value='a2w') src SET pm2.meta_key='_a2w_original_product_url' WHERE pm2.post_id=src.post_id and pm2.meta_key='original_product_url'");
            
            $wpdb->query("UPDATE {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE pm1.meta_key='import_type' and pm1.meta_value='a2w') src SET pm2.meta_key='_a2w_seller_url' WHERE pm2.post_id=src.post_id and pm2.meta_key='seller_url'");
            
            $wpdb->query("UPDATE {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE pm1.meta_key='import_type' and pm1.meta_value='a2w') src SET pm2.meta_key='_a2w_last_update' WHERE pm2.post_id=src.post_id and pm2.meta_key='a2w_last_update'");
            
            $wpdb->query("UPDATE {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE pm1.meta_key='import_type' and pm1.meta_value='a2w') src SET pm2.meta_key='_a2w_skip_meta' WHERE pm2.post_id=src.post_id and pm2.meta_key='a2w_skip_meta'");
            
            $wpdb->query("UPDATE {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE pm1.meta_key='import_type' and pm1.meta_value='a2w') src SET pm2.meta_key='_a2w_disable_var_price_change' WHERE pm2.post_id=src.post_id and pm2.meta_key='a2w_disable_var_price_change'");
            
            $wpdb->query("UPDATE {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE pm1.meta_key='import_type' and pm1.meta_value='a2w') src SET pm2.meta_key='_a2w_reviews_last_update' WHERE pm2.post_id=src.post_id and pm2.meta_key='a2w_reviews_last_update'");
            
            $wpdb->query("UPDATE {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE pm1.meta_key='import_type' and pm1.meta_value='a2w') src SET pm2.meta_key='_a2w_review_page' WHERE pm2.post_id=src.post_id and pm2.meta_key='a2w_review_page'");
            
            $wpdb->query("UPDATE {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE pm1.meta_key='import_type' and pm1.meta_value='a2w') src SET pm2.meta_key='_a2w_shipping_data' WHERE pm2.post_id=src.post_id and pm2.meta_key='a2w_shipping_data'");
            
            $wpdb->query("DELETE pm2 FROM {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE (pm1.meta_key='import_type' or pm1.meta_key='_a2w_import_type') and pm1.meta_value='a2w') src WHERE pm2.post_id=src.post_id and pm2.meta_key='product_url'");
            
            $wpdb->query("UPDATE {$wpdb->postmeta} pm2, (SELECT p.id as post_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON(p.ID=pm1.post_id) WHERE pm1.meta_key='import_type' and pm1.meta_value='a2w') src SET pm2.meta_key='_a2w_import_type' WHERE pm2.post_id=src.post_id and pm2.meta_key='import_type'");
        }
        
        private function migrate_to_121(){
            error_log('migrate to 1.2.1');
            
            $formula_list = a2w_get_transient('a2w_formula_list');
            if($formula_list){
                update_option('a2w_formula_list', $formula_list);
            }
            a2w_delete_transient('a2w_formula_list');
            
            $formula = a2w_get_transient('a2w_default_formula');
            if($formula){
                update_option('a2w_default_formula', $formula);
            }
            a2w_delete_transient('a2w_default_formula');
        }
    }
}
