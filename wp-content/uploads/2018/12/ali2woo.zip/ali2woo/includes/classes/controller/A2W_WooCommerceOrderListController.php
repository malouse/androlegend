<?php
/* * class
 * Description of A2W_WooCommerceOrderListController
 *
 * @author MA_GROUP
 * 
 * @autoload: a2w_init
 */
if (!class_exists('A2W_WooCommerceOrderListController')) :
 
	class A2W_WooCommerceOrderListController {
		
		public function __construct() {
			if(is_admin()) {        
				add_action('admin_enqueue_scripts', array($this, 'assets'));
				add_action('manage_shop_order_posts_custom_column', array($this, 'columns_data'), 100);
                
                add_action('wp_ajax_a2w_order_info', array($this, 'ajax_order_info'));
			}
		}
        
        function ajax_order_info(){
                $result = array("state" => "ok", "data" => "");
              
                $post_id = isset($_POST['id']) ? $_POST['id'] : false;
                
                if (!$post_id) {
                    $result['state'] = 'error';
                    echo json_encode( $result );
                    wp_die();
                }
                
                $content = array();
                   
                $order = new WC_Order($post_id); 
                
                $items = $order->get_items();

                $k = 1;
        
                foreach ($items as $item) {
                    
                    $normalized_item = new A2W_WooCommerceOrderItem($item);
                    
                    $product_name = $normalized_item->getName();
                    $product_id = $normalized_item->getProductID();

                    $product_url = get_post_meta($product_id, '_product_url', true);
                    $seller_url = get_post_meta($product_id, '_a2w_seller_url', true);

                    $tmp = '';
                    
                    if ($product_url)  $tmp =  $k . '). <a title="' . $product_name . '" href="' . $product_url . '" target="_blank" class="link_to_source product_url">Product page</a>';

                    if ($seller_url) $tmp .= "<span class='seller_url_block'> | <a href='" . $seller_url . "' target='_blank' class='seller_url'>Seller</a></span>";
                    
                   
                    
                    $content[] = $tmp;
                    $k++;
                }
        
                $external_order_id = get_post_meta($post_id, '_a2w_external_order_id', true);
                
                if ($external_order_id) $content[] = "<span class='seller_url_block'> | " . $external_order_id . "</span>";

                $content = apply_filters('a2w_get_order_content', $content, $post_id);
                $result['data'] = array( 'content'=> $content, 'id'=> $post_id);
                
                echo json_encode( $result ); 
                wp_die();   
        }
		
		function assets() {
					
	                
			wp_enqueue_style('a2w-wc-ol-style', A2W()->plugin_url . 'assets/css/wc_ol_style.css', array(), A2W()->version);
			wp_enqueue_script('jquery-ui-dialog');
			wp_enqueue_script('a2w-wc-ol-script', A2W()->plugin_url . 'assets/js/wc_ol_script.js', array(), A2W()->version);
			
			$lang_data = array(
				'please_wait_data_loads'=>_x('Please wait, data loads..','Status','a2w'),
			);
			
			wp_localize_script('a2w-wc-ol-script', 'a2w_wc_ol_script', array('lang' => $lang_data));
		}
		
		function columns_data($column){
			 global $post;

			 $actions = array();
			 
			 if ($column == 'order_title'){ 
				$actions = array_merge( $actions, array(
					'a2w_product_info' => sprintf( '<a class="a2w-order-info" id="a2w-%1$d" href="/">%2$s</a>', $post->ID, 'Aliexpress Info' )
				) );
				 
			 }
			 
			 $actions = apply_filters('a2w_wcol_row_actions', $actions, $column);
				 
			 if (count($actions)>0){
				echo implode($actions, ' | ');    
			 }
											
		}    
	}
	
 endif;
