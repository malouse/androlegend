var a2w_reload_page_after_ajax = false;
jQuery(function ($) {

	$(document).on("click", ".a2w-order-info", function () {
		var id = $(this).attr('id').split('-')[1];
		$.a2w_show_order(id);
		return false;
	});

	$.a2w_show_order = function (id) {
		$('<div id="a2w-dialog' + id + '"></div>').dialog({
			dialogClass: 'wp-dialog',
			modal: true,
			title: "Aliexpress Info (ID: " + id + ")",
			open: function () {
				$('#a2w-dialog' + id).html(a2w_wc_ol_script.lang.please_wait_data_loads);
				var data = {'action': 'a2w_order_info', 'id': id};

				$.post(ajaxurl, data, function (response) {
	
					var json = jQuery.parseJSON(response);
				

					if (json.state === 'error') {

						console.log(json);

					} else {
					
						$('#a2w-dialog' + json.data.id).html(json.data.content.join('<br/>'));
					}

				});


			},
			close: function (event, ui) {
				$("#a2w-dialog" + id).remove();
			},
			buttons: {
				Ok: function () {
					$(this).dialog("close");
				}
			}
		});

		return false;

	};

});

